"""
MejorWolf - Navegacion Kodi v2.4.0
3 fuentes en castellano: DonTorrent + EliteTorrent + WolfMax4K.
Menu limpio: Estrenos, Cine, Series, Documentales, Buscar.
"""

import sys
import os
import re
import json
import time
import unicodedata
from urllib.parse import parse_qsl, urlencode, quote
from concurrent.futures import ThreadPoolExecutor

import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

from . import scraper_wolfmax as wf
from . import scraper_elitetorrent as et
from . import scraper_dontorrent as dt
from . import scraper_divxtotal as dx
from . import supabase_sync as sb
from . import tmdb, player
from . import remote_kb as rkb
from . import http_session as hs
from . import dns_doh
from . import torrent as tparse
from . import enlacito

CloudflareChallengeError = hs.CloudflareChallengeError

ADDON   = xbmcaddon.Addon()
HANDLE  = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE    = sys.argv[0] if sys.argv else "plugin://plugin.video.mejorwolf/"

ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
ICON       = os.path.join(ADDON_PATH, "icon2.png")
FANART     = os.path.join(ADDON_PATH, "fanart2.jpg")
DEFAULT_ART = {"fanart": FANART}

_PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
_LAST_SEARCH_FILE = os.path.join(_PROFILE, "last_search.txt")


def _last_search_load():
    try:
        with open(_LAST_SEARCH_FILE, "r", encoding="utf-8") as f:
            return f.read().strip()
    except Exception:
        return ""


def _last_search_save(q):
    try:
        os.makedirs(_PROFILE, exist_ok=True)
        with open(_LAST_SEARCH_FILE, "w", encoding="utf-8") as f:
            f.write(q or "")
    except Exception:
        pass


# ── Snapshot de pantalla para el Teclado Remoto (vista "Lista") ─────────────
# En vez de que el servicio re-pregunte a Kodi por la pantalla (lo que re-
# ejecutaba la busqueda), interceptamos addDirectoryItem y guardamos una "foto"
# de cada pantalla al pintarla. La vista Lista del movil lee esa foto -> es
# instantanea y NO vuelve a buscar.
_SNAP = []
# Guardamos una foto POR RUTA (no solo la ultima). Asi, al navegar hacia atras
# o a una carpeta ya visitada (que Kodi muestra de su cache SIN re-pintar), la
# Lista del movil encuentra la foto correcta de esa ruta -> nunca desincroniza.
_SCREENS_FILE = os.path.join(_PROFILE, "screens.json")


def _snap_save(path):
    try:
        path = (path or "").rstrip("/") or "plugin://plugin.video.mejorwolf"
        data = {}
        if os.path.exists(_SCREENS_FILE):
            try:
                with open(_SCREENS_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f) or {}
            except Exception:
                data = {}
        data[path] = {"items": _SNAP, "ts": time.time()}
        # Conservar solo las 30 pantallas mas recientes
        if len(data) > 30:
            old = sorted(data, key=lambda k: data[k].get("ts", 0))[:len(data) - 30]
            for k in old:
                data.pop(k, None)
        os.makedirs(_PROFILE, exist_ok=True)
        tmp = _SCREENS_FILE + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, _SCREENS_FILE)
    except Exception:
        pass


_orig_add_dir = xbmcplugin.addDirectoryItem


def _add_dir_hook(handle, url, listitem, isFolder=False, totalItems=0):
    try:
        poster = (listitem.getArt("poster") or listitem.getArt("thumb") or "")
        rating = 0.0
        try:
            rating = float(listitem.getVideoInfoTag().getRating() or 0.0)
        except Exception:
            rating = 0.0
        _SNAP.append({"label": listitem.getLabel(), "file": url,
                      "poster": poster, "dir": bool(isFolder),
                      "rating": round(rating, 1)})
    except Exception:
        pass
    return _orig_add_dir(handle, url, listitem, isFolder, totalItems)


xbmcplugin.addDirectoryItem = _add_dir_hook

# Kodi built-in icons — no necesitamos archivos custom
IC = {
    "estrenos":    "DefaultRecentlyAddedMovies.png",
    "movie":       "DefaultMovies.png",
    "tvshow":      "DefaultTVShows.png",
    "documentary": "DefaultVideoPlaylists.png",
    "genre":       "DefaultGenre.png",
    "search":      "DefaultAddonsSearch.png",
    "settings":    "DefaultAddonProgram.png",
    "help":        "DefaultAddonHelp.png",
    "next":        "DefaultFolderBack.png",
}

KIND_LABEL = {
    "estrenos":     "Estrenos",
    "movie":        "Cine",
    "movie_hd":     "Cine HD",
    "movie_4k":     "Cine 4K",
    "movie_720p":   "Cine 720p",
    "movie_hdrip":  "Cine HDRip",
    "movie_micro":  "Cine MicroHD",
    "tvshow":       "Series",
    "tvshow_hd":    "Series HD",
    "tvshow_4k":    "Series 4K",
    "tvshow_720p":  "Series 720p",
    "documentary":  "Documentales",
    "castellano":   "Castellano",
}

SOURCE_LABEL = {"dt": "DonTorrent", "et": "EliteTorrent", "wf": "WolfMax4K",
                "dx": "DivxTotal"}
_SCRAPERS    = {"wf": wf, "dt": dt}


# --- Supabase: actualizar dominios al arrancar ---
def _supabase_startup():
    try:
        for key, setting in [("wolfmax", "wf_base_url"),
                             ("elitetorrent", "et_base_url"),
                             ("dontorrent", "dt_base_url")]:
            domain = sb.get_domain(key)
            if domain:
                current = (ADDON.getSetting(setting) or "").strip()
                prefix = "https://www." if key == "wolfmax" else "https://"
                if domain not in current:
                    new_url = f"{prefix}{domain}"
                    ADDON.setSetting(setting, new_url)
                    xbmc.log(f"[MejorWolf] Supabase: {key} -> {new_url}", xbmc.LOGINFO)
        my_version = ADDON.getAddonInfo("version")
        sb.check_addon_update("addon_mejorwolf", my_version)
    except Exception as e:
        xbmc.log(f"[MejorWolf] Supabase startup (no critico): {e}", xbmc.LOGWARNING)

try:
    _supabase_startup()
except Exception:
    pass


# ── Helpers ─────────────────────────────────────────────────────────────────

def _u(**kwargs):
    return BASE + "?" + urlencode({k: v for k, v in kwargs.items() if v is not None})


def _li(label, info=None, art=None, playable=False, icon=None):
    it  = xbmcgui.ListItem(label=label)
    mrg = dict(DEFAULT_ART)
    mrg.setdefault("icon",  icon or ICON)
    mrg.setdefault("thumb", icon or ICON)
    if art:
        mrg.update({k: v for k, v in art.items() if v})
    it.setArt(mrg)
    if info:
        data = {}
        for k in ("title", "plot", "year", "rating", "mediatype",
                   "season", "episode", "tvshowtitle"):
            v = info.get(k)
            if v in (None, "", 0):
                continue
            if k in ("year", "season", "episode"):
                try:
                    data[k] = int(v)
                except (TypeError, ValueError):
                    continue
            elif k == "rating":
                try:
                    data[k] = float(v)
                except (TypeError, ValueError):
                    continue
            else:
                data[k] = v
        if data:
            it.setInfo("video", data)
    if playable:
        it.setProperty("IsPlayable", "true")
    return it


def _tmdb_kind(kind):
    if kind == "documentary":
        return "documentary"
    if "movie" in kind or kind in ("estrenos", "castellano"):
        return "movie"
    return "tv"


def _media_type(kind):
    if "movie" in kind or kind in ("documentary", "estrenos", "castellano"):
        return "movie"
    return "tvshow"


_RES_RE = re.compile(r"\b(4K|2160p|1080p|720p|480p)\b", re.I)
_SRC_RE = re.compile(
    r"\b(BDremux|BDRemux|Remux|FullBluRay|BluRay|Bluray|BDRip|BRRip|"
    r"WEB-?DL|WEBRip|microHD|MicroHD|HDTV|DVDRip|HDRip)\b", re.I)

# Normalizacion de fuente -> etiqueta bonita
_SRC_NORM = {
    "bdremux": "BDRemux", "remux": "Remux", "fullbluray": "BluRay",
    "bluray": "BluRay", "bdrip": "BDRip", "brrip": "BRRip",
    "webdl": "WEB-DL", "web-dl": "WEB-DL", "webrip": "WEBRip",
    "microhd": "MicroHD", "hdtv": "HDTV", "dvdrip": "DVDRip", "hdrip": "HDRip",
}
# Rango de calidad para ordenar (mayor = mejor)
_RES_RANK = {"4k": 400, "2160p": 400, "1080p": 300, "720p": 200, "480p": 100}
_SRC_RANK = {
    "BDRemux": 60, "Remux": 60, "BluRay": 50, "WEB-DL": 40, "BDRip": 30,
    "BRRip": 30, "MicroHD": 25, "WEBRip": 20, "HDTV": 20, "DVDRip": 10,
    "HDRip": 5,
}


def _quality_parts(text):
    """Devuelve (resolucion, fuente) normalizadas desde un texto, o (None,None)."""
    text = text or ""
    res, src = None, None
    rm = _RES_RE.search(text)
    if rm:
        r = rm.group(1).lower()
        res = "4K" if r in ("4k", "2160p") else r
    sm = _SRC_RE.search(text)
    if sm:
        src = _SRC_NORM.get(sm.group(1).lower().replace("-", ""), None) \
            or _SRC_NORM.get(sm.group(1).lower(), sm.group(1))
    return res, src


def _quality_tag(it):
    """Etiqueta de calidad legible: '1080p BluRay', '4K', '720p'..."""
    src_text = f"{it.get('quality','')} {it.get('title','')}"
    res, src = _quality_parts(src_text)
    if res and src:
        return f"{res} {src}"
    return res or src or (it.get("quality") or "")


def _quality_rank(it):
    """Puntua la calidad para ordenar (mayor = mejor)."""
    res, src = _quality_parts(f"{it.get('quality','')} {it.get('title','')}")
    score = _RES_RANK.get((res or "").lower(), 50)
    score += _SRC_RANK.get(src or "", 0)
    return score


def _display_title(it, year=None):
    """Construye titulo limpio: 'Titulo (2001) [1080p BluRay]'."""
    base = it.get("title") or ""
    # Año
    yr = year or it.get("year")
    if yr:
        yr_str = str(yr)
        # Solo añadir si no esta ya en el titulo
        if yr_str not in base:
            base = f"{base} ({yr_str})"
    # Calidad: etiqueta legible (resolucion + fuente). Solo si no esta ya
    # reflejada en el titulo, para no duplicar (DonTorrent ya la trae).
    tag = _quality_tag(it)
    if tag:
        res, src = _quality_parts(base)
        # Si el titulo ya muestra la resolucion, no añadimos etiqueta
        if not res:
            base = f"{base} [{tag}]"
    return base


# ── Enriquecimiento TMDB ───────────────────────────────────────────────────

def _enrich_one(it):
    source  = it.get("source", "wf")
    scraper = _SCRAPERS.get(source)
    url     = it.get("url")
    alt     = None
    if scraper and url and hasattr(scraper, 'fetch_detail_title'):
        alt = lambda u=url: scraper.fetch_detail_title(u)
    # TMDB para todas las fuentes. Para WolfMax, la portada propia esta
    # bloqueada por Cloudflare (403), asi que dependemos de TMDB. El truco:
    # si el item tiene marca de capitulo (Cap.N / SxxExx) es contenido
    # SERIADO -> forzamos kind="tv". Esto hace que "Rafa" encuentre el
    # documental seriado de TMDB (popularidad 11) en vez de la peli
    # portuguesa de 2012 (popularidad 0.3).
    raw_t = it.get("title", "")
    tmdb_kind = _tmdb_kind(it.get("kind", "movie"))
    if re.search(r"\b[Cc]ap\.?\s*\d+|\b[Ss]\d{1,2}[Ee]\d{1,3}\b", raw_t):
        tmdb_kind = "tv"
    meta = tmdb.enrich(raw_t, kind=tmdb_kind, alt_title_fn=alt)
    # Año: preferir TMDB, fallback al scraper
    year = meta.get("year") or it.get("year")
    # Calidad: asegurar que siempre se propaga
    if not it.get("quality"):
        # Intentar extraer calidad del titulo original del scraper
        raw_title = it.get("title", "")
        qm = re.search(
            r"\b(4K|2160p|1080p|720p|HDRip|BluRay|BDRemux|BDRip|"
            r"WEB-?DL|WEBRip|MicroHD|HDTV|DVDRip|Remux)\b",
            raw_title, re.I,
        )
        if qm:
            it["quality"] = qm.group(1)
    plot = meta.get("plot") or ""
    # Cabecera de NOTAS: SOLO TMDB (gratis, instantaneo, sin bloqueos). Antes se
    # anadia FilmAffinity, pero FA bloquea la IP al recibir peticiones -> quitado
    # de todo el sistema.
    ratings = []
    try:
        tmdb_r = meta.get("rating")
        if tmdb_r and float(tmdb_r) > 0:
            ratings.append("TMDB " + ("%.1f" % float(tmdb_r)).replace(".", ","))
    except Exception:
        pass
    if ratings:
        plot = f"[B]{' · '.join(ratings)}[/B]\n\n{plot}".rstrip()
    info = {
        "title":     _display_title(it, year=year),
        "plot":      plot,
        "year":      year,
        "rating":    meta.get("rating"),
        "mediatype": _media_type(it.get("kind", "movie")),
    }
    art = {}
    own_img = it.get("image") or it.get("thumb")
    # TMDB primero (su CDN image.tmdb.org SIEMPRE carga en Kodi). La imagen
    # propia de WolfMax (wolfmax4k.com/assets) esta tras Cloudflare y da 403
    # en Kodi, asi que solo la usamos como ultimo recurso para fuentes que no
    # sean WF (DT/ET cuyas imagenes si cargan).
    if meta.get("poster"):
        art["poster"] = meta["poster"]
        art["thumb"]  = meta["poster"]
    if meta.get("fanart"):
        art["fanart"] = meta["fanart"]
    if own_img and it.get("source") != "wf":
        art.setdefault("thumb",  own_img)
        art.setdefault("poster", own_img)
    return info, art


def _enrich_many(items, workers=6):
    if not items:
        return []
    # Dedupe de consultas TMDB: varias variantes del mismo titulo (p.ej. 4x
    # "La cosa (The Thing)") comparten UNA sola consulta. Pre-calentamos las
    # claves unicas en paralelo; despues _enrich_one va 100% a cache.
    seen, uniq = set(), []
    for it in items:
        raw_t = it.get("title", "")
        kk = _tmdb_kind(it.get("kind", "movie"))
        if re.search(r"\b[Cc]ap\.?\s*\d+|\b[Ss]\d{1,2}[Ee]\d{1,3}\b", raw_t):
            kk = "tv"
        sig = (kk, tmdb._clean_title(raw_t).lower())
        if sig in seen:
            continue
        seen.add(sig)
        uniq.append(it)
    if len(uniq) < len(items):
        with ThreadPoolExecutor(max_workers=workers) as ex:
            list(ex.map(_enrich_one, uniq))
    with ThreadPoolExecutor(max_workers=workers) as ex:
        return list(ex.map(_enrich_one, items))


def _error(msg, level=xbmcgui.NOTIFICATION_ERROR, dur=8000):
    xbmcgui.Dialog().notification("MejorWolf", msg, level, dur)


# ── Navegacion principal ───────────────────────────────────────────────────

def _warm_wf_catalog():
    """Pre-calienta en segundo plano al abrir el addon (sin bloquear):
      - Catalogo WolfMax (cache en disco) -> 1a busqueda WF lista.
      - Sesion Anubis de DonTorrent en el relay -> los listados DT
        (Cine/Series/Documentales) dejan de tardar 30-40s la 1a vez,
        porque el PoW ya esta resuelto y cacheado en el servidor.
    """
    def _bg_wf():
        try:
            wf._build_catalog()
        except Exception:
            pass

    def _bg_dt():
        try:
            # Toca el relay para que resuelva y cachee la sesion Anubis DT.
            import requests as _rq
            base = dt._render_relay_url()
            dom = dt.resolve_domain()
            if base and dom:
                _rq.get(f"{base}/dtfetch",
                        params={"u": f"https://{dom}/documentales"},
                        timeout=60)
        except Exception:
            pass

    try:
        import threading
        threading.Thread(target=_bg_wf, daemon=True).start()
        threading.Thread(target=_bg_dt, daemon=True).start()
    except Exception:
        pass


class _Timer:
    """Dialogo de progreso con cronometro en vivo. Muestra los segundos que
    lleva cargando para que el usuario vea el tiempo real. Se usa como:
        with _Timer("Cargando documentales...") as t:
            ... trabajo ...
            t.tick("Obteniendo listado")   # actualiza el texto
    Corre un hilo que refresca el contador cada 0.5s.
    """
    def __init__(self, heading):
        self.heading = heading
        self.t0 = time.time()
        self.msg = "Conectando..."
        self._stop = False
        self._dlg = None
        self._th = None

    def __enter__(self):
        try:
            self._dlg = xbmcgui.DialogProgressBG()
            self._dlg.create("MejorWolf", self.heading)
            import threading
            self._th = threading.Thread(target=self._run, daemon=True)
            self._th.start()
        except Exception:
            self._dlg = None
        return self

    def _run(self):
        pct = 0
        while not self._stop:
            try:
                el = time.time() - self.t0
                pct = min(95, pct + 3)
                if self._dlg:
                    self._dlg.update(pct, "MejorWolf",
                                     f"{self.msg}  ({el:.0f}s)")
            except Exception:
                pass
            time.sleep(0.5)

    def tick(self, msg):
        self.msg = msg

    def elapsed(self):
        return time.time() - self.t0

    def __exit__(self, *a):
        self._stop = True
        try:
            if self._dlg:
                self._dlg.close()
        except Exception:
            pass


def home():
    xbmcplugin.setPluginCategory(HANDLE, "MejorWolf")
    # Calentar el catalogo WolfMax en background al abrir el addon.
    _warm_wf_catalog()
    entries = [
        ("Estrenos",      _u(action="estrenos"),                 IC["estrenos"]),
        ("Cine",          _u(action="section", kind="movie"),    IC["movie"]),
        ("Series",        _u(action="section", kind="tvshow"),   IC["tvshow"]),
        ("Documentales",  _u(action="documentales_menu"),       IC["documentary"]),
        ("Géneros",       _u(action="generos_menu"),             IC["genre"]),
        ("Buscar",        _u(action="search"),                   IC["search"]),
        ("Teclado Remoto (móvil)", _u(action="remote_kb"),
         "DefaultAddonRemote.png"),
    ]
    for label, url, ic in entries:
        xbmcplugin.addDirectoryItem(HANDLE, url, _li(label, icon=ic), isFolder=True)
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def estrenos():
    """Estrenos organizados por fuente."""
    xbmcplugin.setPluginCategory(HANDLE, "Estrenos")
    entries = [
        ("DonTorrent",    _u(action="list", src="dt", kind="estrenos", page=1),  IC["estrenos"]),
        ("EliteTorrent",  _u(action="list", src="et", kind="estrenos", page=1),  IC["estrenos"]),
        ("DivxTotal",     _u(action="list", src="dx", kind="movie", page=1),     IC["estrenos"]),
        ("WolfMax4K",     _u(action="list", src="wf", kind="movie", page=1),     IC["estrenos"]),
    ]
    for lab, url, ic in entries:
        xbmcplugin.addDirectoryItem(HANDLE, url, _li(lab, icon=ic), isFolder=True)
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def section(kind):
    """Submenu por FUENTE (DonTorrent / EliteTorrent / WolfMax4K).
    Igual que Estrenos: primero eliges la web, dentro sus calidades. Asi
    cada fuente luce su catalogo por separado, sin mezclar."""
    label = KIND_LABEL.get(kind, kind)
    xbmcplugin.setPluginCategory(HANDLE, label)

    if kind == "movie":
        ic = IC["movie"]
        entries = [
            ("DonTorrent",    _u(action="src_movie", src="dt"), ic),
            ("EliteTorrent",  _u(action="src_movie", src="et"), ic),
            ("DivxTotal",     _u(action="src_movie", src="dx"), ic),
            ("WolfMax4K",     _u(action="src_movie", src="wf"), ic),
            ("Buscar pelicula", _u(action="search", filter_kind="movie"), IC["search"]),
        ]
    elif kind == "tvshow":
        ic = IC["tvshow"]
        entries = [
            ("DonTorrent",    _u(action="src_tvshow", src="dt"), ic),
            ("EliteTorrent",  _u(action="src_tvshow", src="et"), ic),
            ("DivxTotal",     _u(action="src_tvshow", src="dx"), ic),
            ("WolfMax4K",     _u(action="src_tvshow", src="wf"), ic),
            ("Buscar serie",  _u(action="search", filter_kind="tvshow"), IC["search"]),
        ]
    else:
        entries = [
            (f"Ultimas {label}", _u(action="list", src="dt", kind=kind, page=1), IC.get("documentary", IC["movie"])),
        ]

    for lab, url, ic2 in entries:
        xbmcplugin.addDirectoryItem(HANDLE, url, _li(lab, icon=ic2), isFolder=True)
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


# Calidades disponibles por fuente para peliculas y series.
_SRC_MOVIE_QUALITIES = {
    "dt": [("Películas", "movie"), ("Películas HD", "movie_hd"),
           ("Películas 4K", "movie_4k")],
    "et": [("Estrenos", "estrenos"), ("Películas 720p", "movie_720p"),
           ("Películas HDRip", "movie_hdrip"), ("Películas MicroHD", "movie_micro")],
    "wf": [("Películas 1080p", "movie_hd"), ("Películas 4K", "movie_4k")],
    "dx": [("Películas", "movie")],
}
_SRC_TVSHOW_QUALITIES = {
    "dt": [("Series", "tvshow"), ("Series HD", "tvshow_hd"),
           ("Series 4K", "tvshow_4k")],
    "et": [("Series", "tvshow")],
    "wf": [("Series 1080p", "tvshow_hd"), ("Series 4K", "tvshow_4k")],
    "dx": [("Series", "tvshow")],
}


def src_section(src, kind):
    """Lista las calidades de una fuente concreta (movie o tvshow)."""
    table = _SRC_MOVIE_QUALITIES if kind == "movie" else _SRC_TVSHOW_QUALITIES
    quals = table.get(src, [])
    ic = IC["movie"] if kind == "movie" else IC["tvshow"]
    xbmcplugin.setPluginCategory(HANDLE, SOURCE_LABEL.get(src, src))
    for lab, k in quals:
        xbmcplugin.addDirectoryItem(
            HANDLE, _u(action="list", src=src, kind=k, page=1),
            _li(lab, icon=ic), isFolder=True)
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def documentales_menu():
    """Submenu de Documentales por fuente (igual que Cine/Series)."""
    xbmcplugin.setPluginCategory(HANDLE, "Documentales")
    ic = IC["documentary"]
    entries = [
        ("DonTorrent",   _u(action="list", src="dt", kind="documentary", page=1), ic),
        ("WolfMax4K",    _u(action="list", src="wf", kind="documentary", page=1), ic),
        ("EliteTorrent", _u(action="et_genre", genre="documental", page=1),       ic),
    ]
    for lab, url, ic2 in entries:
        xbmcplugin.addDirectoryItem(HANDLE, url, _li(lab, icon=ic2), isFolder=True)
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE)


def generos_menu():
    """Generos cinematograficos (EliteTorrent)."""
    xbmcplugin.setPluginCategory(HANDLE, "Géneros")
    for key in sorted(et.GENRE_LABELS.keys()):
        label = et.GENRE_LABELS[key]
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _u(action="et_genre", genre=key, page=1),
            _li(label, icon=IC["genre"]),
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(HANDLE)


# ── Listados unificados ────────────────────────────────────────────────────

def list_items(src, kind, page=1):
    """Lista items de cualquier fuente."""
    label = KIND_LABEL.get(kind, kind)
    src_name = SOURCE_LABEL.get(src, src)
    xbmcplugin.setPluginCategory(HANDLE, label)

    with _Timer(f"Cargando {label} ({src_name})...") as timer:
        try:
            timer.tick(f"Obteniendo listado de {src_name}")
            if src == "dt":
                items = dt.latest(kind=kind, page=page)
            elif src == "et":
                result = et.latest(kind=kind, page=page)
                items = result[0] if isinstance(result, tuple) else result
            elif src == "wf":
                items = wf.latest(kind=kind, page=page)
            elif src == "dx":
                items = dx.latest(kind=kind, page=page)
            else:
                items = []
        except CloudflareChallengeError:
            _error("Sitio bloqueado temporalmente. Prueba más tarde.",
                   xbmcgui.NOTIFICATION_WARNING)
            xbmcplugin.endOfDirectory(HANDLE)
            return
        except Exception as e:
            xbmc.log(f"[MejorWolf] list error: {e}", xbmc.LOGERROR)
            _error(f"Error de conexión: {type(e).__name__}")
            xbmcplugin.endOfDirectory(HANDLE)
            return

        if not items:
            _error("Sin resultados.", xbmcgui.NOTIFICATION_WARNING, 5000)
            xbmcplugin.endOfDirectory(HANDLE)
            return

        timer.tick(f"Cargando portadas ({len(items)} resultados)")
        enriched = _enrich_many(items)
        xbmc.log(f"[MejorWolf] list {src}/{kind} cargado en "
                 f"{timer.elapsed():.1f}s ({len(items)} items)", xbmc.LOGINFO)
    for it, (info, art) in zip(items, enriched):
        is_wf_series = it.get("kind", "").startswith("tvshow") and it.get("source") == "wf"
        if is_wf_series:
            url = _u(action="wf_series", q=it["title"], seed_url=it["url"],
                     title=it["title"])
        else:
            url = _u(action="detail", src=it.get("source", src),
                     url=it["url"], kind=it.get("kind", kind),
                     title=it["title"])
        xbmcplugin.addDirectoryItem(HANDLE, url,
                                    _li(info["title"], info=info, art=art),
                                    isFolder=True)

    # Pagina siguiente
    next_page = page + 1
    xbmcplugin.addDirectoryItem(
        HANDLE,
        _u(action="list", src=src, kind=kind, page=next_page),
        _li(f"Pagina siguiente ({next_page}) >>", icon=IC["next"]),
        isFolder=True,
    )

    content = "movies" if _media_type(kind) == "movie" else "tvshows"
    xbmcplugin.setContent(HANDLE, content)
    xbmcplugin.endOfDirectory(HANDLE)


def et_genre(genre_key, page=1):
    """Lista items por genero (EliteTorrent)."""
    label = et.GENRE_LABELS.get(genre_key, genre_key)
    xbmcplugin.setPluginCategory(HANDLE, label)
    try:
        items, next_url = et.genre(genre_key, page=page)
    except Exception as e:
        xbmc.log(f"[MejorWolf] et_genre error: {e}", xbmc.LOGERROR)
        _error(f"Error: {type(e).__name__}")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    if not items:
        _error("Sin resultados en este género.", xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    enriched = _enrich_many(items)
    for it, (info, art) in zip(items, enriched):
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _u(action="detail", src="et", url=it["url"],
               kind=it.get("kind", "movie"), title=it["title"]),
            _li(info["title"], info=info, art=art),
            isFolder=True,
        )

    if next_url:
        next_page = page + 1
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _u(action="et_genre", genre=genre_key, page=next_page),
            _li(f"Pagina siguiente ({next_page}) >>", icon=IC["next"]),
            isFolder=True,
        )

    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.endOfDirectory(HANDLE)


# ── Detalle ─────────────────────────────────────────────────────────────────

def detail(src, url, kind, title):
    """Ficha de detalle — dispatcha al scraper correcto."""
    if src == "dt":
        return _detail_dt(url, kind, title)
    if src == "et":
        return _detail_et(url, kind, title)
    if src == "dx":
        return _detail_dx(url, kind, title)
    return _detail_wf(url, kind, title)


def _detail_dt(url, kind, title):
    """Ficha DonTorrent: descargas con PoW."""
    try:
        d = dt.detail(url)
    except Exception as e:
        xbmc.log(f"[MejorWolf] dt detail error: {e}", xbmc.LOGERROR)
        _error(f"Error DonTorrent: {type(e).__name__}")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    alt = (lambda t=d.get("title"): t) if d.get("title") else None
    meta = tmdb.enrich(title, kind=_tmdb_kind(kind), alt_title_fn=alt)
    art = _build_art(meta, d)
    info_base = _build_info_base(meta, d)

    movie_label = d.get("title") or title or "Película"
    has_episodes = any(dl.get("season") is not None for dl in d["downloads"])
    year_str = f" ({meta.get('year') or d.get('year', '')})" if (meta.get("year") or d.get("year")) else ""

    for dl in d["downloads"]:
        if has_episodes and dl.get("season") is None:
            continue

        quality = dl.get("quality", "")

        if has_episodes:
            label = dl.get("label", "Capítulo")
            if quality and quality.lower() not in label.lower():
                label = f"{label} [{quality}]"
            mtype = "episode"
        else:
            label = movie_label + year_str
            if quality and quality.lower() not in label.lower():
                label = f"{label} [{quality}]"
            mtype = "movie"

        item_info = dict(info_base, title=label, mediatype=mtype)
        if has_episodes and dl.get("season") is not None:
            item_info["season"]  = dl["season"]
            item_info["episode"] = dl.get("episode", 0)

        xbmcplugin.addDirectoryItem(
            HANDLE,
            _u(action="dt_play", content_id=dl["content_id"],
               tabla=dl["tabla"], page_url=url, t=label),
            _li(label, info=item_info, art=art, playable=True),
            isFolder=False,
        )

    if not d["downloads"]:
        _error("Sin enlaces de descarga.", xbmcgui.NOTIFICATION_WARNING, 6000)
    xbmcplugin.endOfDirectory(HANDLE)


def _detail_et(url, kind, title):
    """Ficha EliteTorrent: magnets directos."""
    try:
        results, info = et.detail(url)
    except Exception as e:
        xbmc.log(f"[MejorWolf] et detail error: {e}", xbmc.LOGERROR)
        _error(f"Error EliteTorrent: {type(e).__name__}")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    meta = tmdb.enrich(title, kind=_tmdb_kind(kind))
    art = _build_art(meta, info)
    info_base = _build_info_base(meta, info)
    movie_label = info.get("title") or title or "Descarga"
    year_str = f" ({meta.get('year')})" if meta.get("year") else ""

    for dl in results:
        magnet = dl.get("magnet")
        if not magnet:
            continue
        quality = dl.get("quality", "")
        label = movie_label + year_str
        if quality and quality.lower() not in label.lower():
            label = f"{label} [{quality}]"

        item_info = dict(info_base, title=label, mediatype=_media_type(kind))
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _u(action="play", torrent=magnet, t=label),
            _li(label, info=item_info, art=art, playable=True),
            isFolder=False,
        )

    if not results:
        _error("Sin enlaces de descarga.", xbmcgui.NOTIFICATION_WARNING, 6000)
    xbmcplugin.endOfDirectory(HANDLE)


def _add_dx_episodes(eps, info_base, art, show_label):
    """Lista episodios DivxTotal (reproducibles) ordenados por temporada/cap."""
    for dl in sorted(eps, key=lambda d: (d.get("season") or 0,
                                         d.get("episode") or 0)):
        s = dl.get("season") or 0
        e = dl.get("episode") or 0
        q = dl.get("quality", "")
        label = "%dx%02d" % (s, e)
        if q and q.lower() not in label.lower():
            label = f"{label} [{q}]"
        info = dict(info_base, title=label, mediatype="episode",
                    season=s, episode=e)
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _u(action="play", torrent=dl["torrent_url"],
               t="%s %dx%02d" % (show_label, s, e)),
            _li(label, info=info, art=art, playable=True),
            isFolder=False,
        )


def _detail_dx(url, kind, title):
    """Ficha DivxTotal. Películas: ítem reproducible. Series: agrupadas por
    TEMPORADA (igual que DonTorrent/WolfMax). play() baja el .torrent vía relay."""
    try:
        d = dx.detail(url)
    except Exception as e:
        xbmc.log(f"[MejorWolf] dx detail error: {e}", xbmc.LOGERROR)
        _error(f"Error DivxTotal: {type(e).__name__}")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    meta = tmdb.enrich(title, kind=_tmdb_kind(kind))
    art = _build_art(meta, d)
    info_base = _build_info_base(meta, d)
    show_label = d.get("title") or title or "Película"
    year_str = f" ({meta.get('year') or d.get('year', '')})" if (
        meta.get("year") or d.get("year")) else ""
    downloads = d.get("downloads", [])
    eps = [dl for dl in downloads if dl.get("season") is not None]

    if eps:
        # SERIE: una carpeta por temporada; si solo hay una, episodios directos.
        seasons = sorted(set(dl["season"] for dl in eps))
        xbmcplugin.setPluginCategory(HANDLE, show_label)
        if len(seasons) > 1:
            xbmcplugin.setContent(HANDLE, "seasons")
            for s in seasons:
                n = sum(1 for dl in eps if dl["season"] == s)
                lab = f"Temporada {s}  ({n} cap.)"
                info = dict(info_base, title=lab, mediatype="season", season=s)
                xbmcplugin.addDirectoryItem(
                    HANDLE,
                    _u(action="dx_season", url=url, season=s, title=show_label),
                    _li(lab, info=info, art=art),
                    isFolder=True)
        else:
            xbmcplugin.setContent(HANDLE, "episodes")
            _add_dx_episodes(eps, info_base, art, show_label)
    else:
        # PELÍCULA
        xbmcplugin.setContent(HANDLE, "movies")
        for dl in downloads:
            q = dl.get("quality", "")
            label = show_label + year_str
            if q and q.lower() not in label.lower():
                label = f"{label} [{q}]"
            info = dict(info_base, title=label, mediatype="movie")
            xbmcplugin.addDirectoryItem(
                HANDLE,
                _u(action="play", torrent=dl["torrent_url"], t=label),
                _li(label, info=info, art=art, playable=True),
                isFolder=False)
        if not downloads:
            _error("Sin enlaces de descarga.",
                   xbmcgui.NOTIFICATION_WARNING, 6000)
    xbmcplugin.endOfDirectory(HANDLE)


def dx_season(url, season, title=""):
    """Episodios de UNA temporada de una serie DivxTotal (re-lee la ficha)."""
    try:
        season = int(season)
    except (TypeError, ValueError):
        season = 1
    try:
        d = dx.detail(url)
    except Exception as e:
        xbmc.log(f"[MejorWolf] dx_season error: {e}", xbmc.LOGERROR)
        _error(f"Error DivxTotal: {type(e).__name__}")
        xbmcplugin.endOfDirectory(HANDLE)
        return
    show_label = d.get("title") or title or "Serie"
    meta = tmdb.enrich(show_label, kind="tv")
    art = _build_art(meta, d)
    info_base = _build_info_base(meta, d)
    eps = [dl for dl in d.get("downloads", []) if dl.get("season") == season]
    xbmcplugin.setPluginCategory(HANDLE, f"{show_label} · Temporada {season}")
    xbmcplugin.setContent(HANDLE, "episodes")
    _add_dx_episodes(eps, info_base, art, show_label)
    if not eps:
        _error("Sin episodios.", xbmcgui.NOTIFICATION_WARNING, 5000)
    xbmcplugin.endOfDirectory(HANDLE)


def _detail_wf(url, kind, title):
    """Ficha WolfMax4K: torrents via enlacito."""
    try:
        d = wf.detail(url)
    except Exception as e:
        xbmc.log(f"[MejorWolf] wf detail error: {e}", xbmc.LOGERROR)
        _error(f"Error WolfMax: {type(e).__name__}")
        xbmcplugin.endOfDirectory(HANDLE)
        return

    alt  = (lambda t=d.get("title"): t) if d.get("title") else None
    # Si el titulo tiene marca de capitulo es contenido seriado -> TMDB tv,
    # asi "Rafa [Cap.101]" encuentra el documental seriado (2026) y no la
    # peli portuguesa de 2012. Mismo criterio que en _enrich_one.
    wf_kind = _tmdb_kind(kind)
    if re.search(r"\b[Cc]ap\.?\s*\d+|\b[Ss]\d{1,2}[Ee]\d{1,3}\b", title or ""):
        wf_kind = "tv"
    meta = tmdb.enrich(title, kind=wf_kind, alt_title_fn=alt)
    # Portada: TMDB (image.tmdb.org carga en Kodi). La imagen propia de
    # WolfMax esta tras Cloudflare (403) -> NO usarla.
    art = {}
    if meta.get("poster"):
        art["poster"] = meta["poster"]; art["thumb"] = meta["poster"]
    if meta.get("fanart"):
        art["fanart"] = meta["fanart"]
    info_base = _build_info_base(meta, d)
    year_str = f" ({meta.get('year') or d.get('year', '')})" if (meta.get("year") or d.get("year")) else ""

    has_episodes = any(x.get("season") is not None for x in d["downloads"])
    movie_label  = (d.get("title") or title or "").strip() or "Descarga"

    for dl in d["downloads"]:
        if has_episodes and dl.get("season") is None:
            continue
        if has_episodes:
            label = dl["label"]
            mtype = "episode"
        else:
            label = movie_label + year_str
            extras = dl.get("label", "")
            if extras and extras.lower() not in ("descargar", "descargar ahora",
                                                  movie_label.lower()):
                label = f"{label} - {extras}"
            mtype = "movie"
        info = dict(info_base, title=label, mediatype=mtype)
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _u(action="play", torrent=dl["torrent_url"], t=label),
            _li(label, info=info, art=art, playable=True),
            isFolder=False,
        )

    if not d["downloads"]:
        _error("Sin enlaces de descarga.", xbmcgui.NOTIFICATION_WARNING, 6000)
    xbmcplugin.endOfDirectory(HANDLE)


def _build_art(meta, d):
    art = {}
    if meta.get("poster"):
        art["poster"] = meta["poster"]
        art["thumb"]  = meta["poster"]
    if meta.get("fanart"):
        art["fanart"] = meta["fanart"]
    img = d.get("image") or d.get("thumb")
    if img:
        art.setdefault("thumb",  img)
        art.setdefault("poster", img)
    return art


def _build_info_base(meta, d):
    return {
        "plot":   meta.get("plot") or d.get("plot"),
        "year":   meta.get("year") or d.get("year"),
        "rating": meta.get("rating"),
    }


# ── Reproduccion ────────────────────────────────────────────────────────────

def _elementum_installed():
    try:
        xbmcaddon.Addon("plugin.video.elementum")
        return True
    except Exception:
        return False


def _check_elementum():
    if not _elementum_installed():
        xbmcgui.Dialog().ok(
            "MejorWolf",
            "Elementum no esta instalado o esta deshabilitado.\n"
            "Instala 'plugin.video.elementum' desde su repositorio.",
        )
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return False
    return True


def _set_np_title(title):
    """Guarda el titulo limpio de lo que se va a reproducir para que el panel
    'Estas viendo' del mando muestre el nombre real. Elementum no rellena
    VideoPlayer.Title de forma fiable, asi que lo dejamos aqui: el servicio lo
    lee. Quitamos la [calidad] del final para que quede limpio."""
    try:
        import xbmcvfs
        clean = re.sub(r"\s*\[[^\]]*\]\s*$", "", title or "").strip()
        if not clean:
            return
        p = xbmcvfs.translatePath("special://temp/mejorwolf_np.txt")
        with open(p, "w", encoding="utf-8") as f:
            f.write(clean)
    except Exception:
        pass


def _set_continue(title, a, ci="", tb="", u=""):
    """Guarda QUÉ se está reproduciendo (título + referencia replayable) para
    'Continuar viendo'. El servicio actualiza la posición (elapsed/total) y lo
    sube al relay en el latido."""
    try:
        import xbmcvfs
        clean = re.sub(r"\s*\[[^\]]*\]\s*$", "", title or "").strip()
        rec = {"title": clean, "a": a, "ci": str(ci or ""),
               "tb": str(tb or ""), "u": u or "",
               "elapsed": 0, "total": 0, "ts": time.time()}
        p = xbmcvfs.translatePath("special://temp/mejorwolf_continue.json")
        with open(p, "w", encoding="utf-8") as f:
            json.dump(rec, f)
    except Exception:
        pass


def play(torrent_url, title=""):
    """Reproduce un magnet o URL de .torrent via Elementum."""
    if not torrent_url:
        _error("URL de torrent vacía")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    if not _check_elementum():
        return

    xbmc.log(f"[MejorWolf] play: {torrent_url[:160]}", xbmc.LOGINFO)

    progress = xbmcgui.DialogProgressBG()
    try:
        progress.create("MejorWolf", "Obteniendo torrent...")
    except Exception:
        progress = None

    # WolfMax, web nueva (2.9.77): enlace DIFERIDO "wf2:<tabla>:<id>". El
    # torrent se pide ahora (prueba de trabajo), no al listar la temporada.
    if torrent_url.startswith("wf2:"):
        try:
            if progress:
                progress.update(15, "MejorWolf", "Pidiendo el torrent a WolfMax...")
        except Exception:
            pass
        try:
            torrent_url = wf.resolver_diferido(torrent_url) or ""
        except Exception as e:
            xbmc.log(f"[MejorWolf] wf2: {e}", xbmc.LOGWARNING)
            torrent_url = ""
        if not torrent_url:
            try:
                if progress:
                    progress.close()
            except Exception:
                pass
            _error("WolfMax no ha dado el torrent ahora mismo. Inténtalo en un rato.")
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return

    # Enlacito shortener
    if enlacito.is_enlacito_url(torrent_url):
        try:
            if progress:
                progress.update(20, "MejorWolf", "Resolviendo enlacito...")
        except Exception:
            pass
        resolved = enlacito.resolve(torrent_url)
        if resolved:
            torrent_url = resolved
    low = torrent_url.lower()

    # HTTP URL → fetch .torrent → magnet
    orig_http = None          # URL .torrent original (para dársela a Elementum)
    relay_torrent_src = None  # .torrent servido por el relay (con metadatos)
    if low.startswith(("http://", "https://")):
        orig_http = torrent_url
        try:
            # Bajar el .torrent vía RELAY (IP de datacenter, sin bloqueo ISP):
            # fuentes como DivxTotal están bloqueadas en directo desde el box.
            data = b""
            try:
                # WolfMax NO por el relay: desde Render le pone un reto de
                # Cloudflare (y por alli gastaria creditos de ScraperAPI). La
                # caja lo baja ella misma, con sus caminos de respaldo.
                relay_url = "" if "wolfmax4k." in low else dt._render_relay_url()
                if relay_url:
                    import requests as _rq
                    rr = _rq.get(f"{relay_url}/relay",
                                 params={"u": torrent_url}, timeout=30)
                    if rr.status_code == 200 and len(rr.content) > 100:
                        data = rr.content
                        # Si el relay sirve el .torrent, se lo damos a Elementum
                        # POR AQUÍ: baja el .torrent COMPLETO (metadatos al
                        # instante) -> no se cuelga en "resolviendo" cuando hay
                        # pocas/ninguna semilla (problema típico de DivxTotal).
                        relay_torrent_src = (
                            f"{relay_url}/relay?u={quote(orig_http, safe='')}")
            except Exception:
                data = b""
            # Fallback: directo (PC / redes sin bloqueo, o host no permitido).
            if not data:
                sess = hs.make_session()
                r = hs.get(sess, torrent_url, timeout=30)
                data = r.content or b""
            # Aviso RAR (sin red extra: leemos los bytes ya descargados).
            if data and tparse.is_packed(data):
                if not xbmcgui.Dialog().yesno(
                        "MejorWolf",
                        "Este contenido viene comprimido en RAR y puede que no "
                        "se reproduzca.\n¿Intentar de todas formas?",
                        nolabel="Cancelar", yeslabel="Intentar"):
                    try:
                        if progress:
                            progress.close()
                    except Exception:
                        pass
                    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                    return
            magnet = tparse.torrent_to_magnet(data)
            if magnet:
                torrent_url = magnet
                low = magnet.lower()
            else:
                text = data.decode("utf-8", "replace")
                mm = re.search(r'(magnet:\?[^"\'<>\s]+)', text)
                if mm:
                    torrent_url = mm.group(1)
                    low = torrent_url.lower()
                else:
                    mm = re.search(r'href="([^"]+\.torrent[^"]*)"', text, re.I)
                    if mm:
                        from urllib.parse import urljoin as _uj
                        inner = _uj(torrent_url, mm.group(1))
                        r2 = hs.get(sess, inner, timeout=30)
                        magnet = tparse.torrent_to_magnet(r2.content or b"")
                        if magnet:
                            torrent_url = magnet
                            low = magnet.lower()
        except Exception as e:
            xbmc.log(f"[MejorWolf] torrent fetch: {e}", xbmc.LOGWARNING)

    if not relay_torrent_src and not (
            low.startswith("magnet:") or low.endswith(".torrent")
            or low.startswith("file://")):
        try:
            if progress:
                progress.close()
        except Exception:
            pass
        _error("No se pudo obtener el torrent.")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return

    # Preferimos darle a Elementum el .torrent COMPLETO vía relay (trae los
    # metadatos = no se cuelga en "resolviendo"); si no hubo relay, el magnet.
    elem_src = relay_torrent_src or torrent_url
    play_url = player.elementum_url(elem_src)
    try:
        if progress:
            progress.close()
    except Exception:
        pass

    _set_np_title(title)
    _set_continue(title, "pl", u=torrent_url)
    item = xbmcgui.ListItem(path=play_url)
    item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def _dt_magnet_relay(content_id, tabla, title=""):
    """magnet de un item de DonTorrent que el relay ya conoce (su huella la
    guardan el aprendiz y las semillas), sin tocar DonTorrent. '' si no la
    sabe o si el relay es anterior a /dtmagnet (dtbl38)."""
    try:
        base = dt._render_relay_url()
        if not base:
            return ""
        import requests as _rq
        r = _rq.get(f"{base}/dtmagnet",
                    params={"c": content_id, "tb": tabla, "t": title or ""},
                    timeout=8)
        if r.status_code == 200:
            m = ((r.json() or {}).get("magnet") or "").strip()
            if m.startswith("magnet:?xt=urn:btih:"):
                return m
    except Exception as e:
        xbmc.log(f"[MejorWolf] dtmagnet: {e}", xbmc.LOGWARNING)
    return ""


def dt_play(content_id, tabla, page_url="", title=""):
    """Resuelve PoW de DonTorrent y reproduce."""
    if not content_id or not tabla:
        _error("Faltan datos de descarga")
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    if not _check_elementum():
        return

    progress = xbmcgui.DialogProgressBG()
    try:
        progress.create("MejorWolf", "Resolviendo descarga...")
    except Exception:
        progress = None

    try:
        try:
            if progress:
                progress.update(30, "MejorWolf", "Resolviendo PoW...")
        except Exception:
            pass

        torrent_url = dt.resolve_torrent(content_id, tabla, page_url=page_url)
        if not torrent_url:
            raise RuntimeError("No se obtuvo URL del torrent")

        xbmc.log(f"[MejorWolf] dt resolved: {torrent_url[:160]}", xbmc.LOGINFO)

        try:
            if progress:
                progress.update(60, "MejorWolf", "Descargando torrent...")
        except Exception:
            pass

        # Descargar .torrent y guardarlo en temp para que Elementum
        # lo lea directamente (evita timeout resolviendo magnet via DHT)
        try:
            if progress:
                progress.update(60, "MejorWolf", "Descargando torrent...")
        except Exception:
            pass

        # Descargar los BYTES del .torrent. PRIMERO desde el BOX (DoH/proxy, que
        # SI resuelven Anubis): el .torrent viene tras un reto Anubis, asi que un
        # GET generico baja la pagina de reto, no el .torrent. Ademas la IP de
        # Render esta bloqueada por DonTorrent, asi que el relay no sirve aqui.
        torrent_data = None
        try:
            torrent_data = dt.download_torrent(torrent_url)
        except Exception:
            torrent_data = None

        # Fallback: relay /dtfetch (por si el box no alcanza y Render no esta
        # bloqueado). Validamos que sea un .torrent real (bencode 'd').
        if not torrent_data:
            try:
                relay_url = dt._render_relay_url()
                if relay_url:
                    from urllib.parse import quote as _q
                    fetch_url = f"{relay_url}/dtfetch?u={_q(torrent_url, safe='')}"
                    import requests as _rq
                    rr = _rq.get(fetch_url, timeout=20)
                    if (rr.status_code == 200 and len(rr.content) > 100
                            and rr.content[:1] == b"d"):
                        torrent_data = rr.content
            except Exception:
                pass

        # Aviso RAR: si el .torrent trae el video comprimido, Elementum no lo
        # reproducira. Lo detectamos leyendo los bytes que YA tenemos (sin red)
        # y dejamos elegir al usuario en vez de fallar en silencio.
        if torrent_data and tparse.is_packed(torrent_data):
            try:
                if progress:
                    progress.close()
            except Exception:
                pass
            if not xbmcgui.Dialog().yesno(
                    "MejorWolf",
                    "Este contenido viene comprimido en RAR y puede que no se "
                    "reproduzca.\n¿Intentar de todas formas?",
                    nolabel="Cancelar", yeslabel="Intentar"):
                xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
                return

        # Guardar .torrent en temp y pasar file:// a Elementum
        # Esto evita el problema de "Expired timeout for resolving magnet"
        # porque Elementum tiene la metadata completa del torrent de inmediato.
        play_uri = None
        if torrent_data and len(torrent_data) > 100:
            try:
                import xbmcvfs
                temp_dir = xbmcvfs.translatePath("special://temp/")
                torrent_file = os.path.join(temp_dir, "mejorwolf_play.torrent")
                with open(torrent_file, "wb") as tf:
                    tf.write(torrent_data)
                play_uri = torrent_file
                xbmc.log(f"[MejorWolf] torrent saved to {torrent_file} "
                         f"({len(torrent_data)} bytes)", xbmc.LOGINFO)
            except Exception as e:
                xbmc.log(f"[MejorWolf] save torrent failed: {e}",
                         xbmc.LOGWARNING)

        # Fallback: magnet URI (puede tardar 60s+ en resolver metadata)
        if not play_uri:
            magnet = tparse.torrent_to_magnet(torrent_data or b"")
            # SIN .torrent no hay nada que darle a Elementum. Antes se le pasaba
            # la URL de DonTorrent "por si acaso", y el tampoco puede con ella
            # (reto Anubis, y en casa el operador corta su IP). 23-09, con su
            # web caida: "Could not resolve torrent" en el log y la tele sin
            # hacer NADA tras "Descargando torrent...", ni un aviso. Ahora: si
            # el relay ya sabe la huella de ese torrent, magnet (el enjambre
            # sigue vivo aunque DonTorrent no); si no, se dice lo que pasa.
            if not magnet:
                magnet = _dt_magnet_relay(content_id, tabla, title)
                if magnet:
                    xbmc.log("[MejorWolf] dt_play: sin .torrent -> magnet del "
                             "relay (huella sabida)", xbmc.LOGINFO)
            if not magnet:
                raise RuntimeError("No se pudo descargar el torrent ahora "
                                   "mismo. Inténtalo de nuevo en un rato.")
            play_uri = magnet

        try:
            if progress:
                progress.close()
        except Exception:
            pass

        _set_np_title(title)
        _set_continue(title, "dt", ci=content_id, tb=tabla)
        play_url = player.elementum_url(play_uri)
        item = xbmcgui.ListItem(path=play_url)
        item.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(HANDLE, True, item)

    except Exception as e:
        try:
            if progress:
                progress.close()
        except Exception:
            pass
        xbmc.log(f"[MejorWolf] dt_play error: {e}", xbmc.LOGERROR)
        # Lo que ve el USUARIO tiene que ser una frase, no una traza. El caso
        # tipico ("POST JSON fallo: doh: ConnectionReset...") es el operador
        # cortando la conexion con DonTorrent mientras el relay no estaba: se
        # arregla solo en un minuto, asi que eso es lo que hay que decirle.
        _msg = str(e)
        # DonTorrent CAIDO de verdad (su pagina de "volvera enseguida", 23-09):
        # ni es la tele ni se arregla en un minuto, y hay que decirlo asi.
        _mant = False
        try:
            _mant = dt.en_mantenimiento()
        except Exception:
            pass
        if _mant:
            _msg = ("DonTorrent está caído ahora mismo (su web no responde). "
                    "Suele volver solo en unas horas.")
        elif ("doh" in _msg or "JSON fallo" in _msg or "Connection" in _msg
                or "sin challenge" in _msg):
            _msg = ("No se pudo preparar la descarga ahora mismo. "
                    "Inténtalo de nuevo en un minuto.")
        elif len(_msg) > 90:
            _msg = _msg[:90] + "…"
        _error(_msg)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())


# ── Busqueda combinada ─────────────────────────────────────────────────────

_SHOW_MARKERS_RE = re.compile(
    r"\[[^\]]*\]"
    r"|\([^)]*\)"
    r"|\bS\d{1,2}E\d{1,3}\b"
    r"|\b\d{1,2}\s*[xX]\s*\d{1,3}\b"
    r"|\bCap[ií]?tulos?\s*\d+\b"
    r"|\bTemporada\s*\d+\b"
    r"|\bEpisodios?\s*\d+\b"
    r"|\b(?:HDTV|WEB-?DL|WEB-?Rip|BluRay|BDRip|BRRip|HEVC|x265|x264|"
    r"4K\s*UHD|4K|2160p|1080p|720p|480p|HDR10\+?|HDR|DV|Dolby\s*Vision|"
    r"Remux|BDRemux|Latino|Castellano|Dual|VOSE|Esp|Ing|MicroHD)\b",
    re.I,
)


def _norm_for_group(s):
    if not s:
        return ""
    s = unicodedata.normalize("NFKD", s)
    s = "".join(c for c in s if not unicodedata.combining(c))
    return re.sub(r"\s+", " ", s.lower().strip())


def _series_base(title):
    if not title:
        return ""
    t = _SHOW_MARKERS_RE.sub("", title)
    t = re.sub(r"\s+", " ", t).strip(" -.|:")
    return t


def _ep_key(title):
    if not title:
        return (99, 99)
    m = re.search(r"[Cc]ap\.?\s*(\d{1,3})(\d{2})", title)
    if m:
        return (int(m.group(1)), int(m.group(2)))
    m = re.search(r"\b(\d{1,2})\s*[xX]\s*(\d{1,3})\b", title)
    if m:
        return (int(m.group(1)), int(m.group(2)))
    m = re.search(r"\bS(\d{1,2})E(\d{1,3})\b", title, re.I)
    if m:
        return (int(m.group(1)), int(m.group(2)))
    m = re.search(r"[Cc]ap(?:[ií]?tulos?)?\.?\s*(\d{1,3})\b", title)
    if m:
        return (1, int(m.group(1)))
    return (99, 99)


def _ep_label(it):
    title = it.get("title", "")
    s, e = _ep_key(title)
    if s == 99:
        return _display_title(it)
    quality = it.get("quality")
    if not quality:
        m = re.search(r"\[([^\]]+)\]", title)
        if m:
            quality = m.group(1).strip()
    label = f"{s:02d}x{e:02d}"
    if quality:
        label = f"{label} [{quality}]"
    return label


def _group_results(items):
    order = []
    groups = {}
    for it in items:
        title = it.get("title") or ""
        base = _series_base(title)
        if not base:
            base = title.strip() or "Sin titulo"
        src = it.get("source") or "?"
        nb = _norm_for_group(base)
        key = f"{src}|{nb}"
        if key not in groups:
            groups[key] = {
                "key": key, "base": base,
                "kind": it.get("kind") or "movie",
                "source": src, "items": [],
            }
            order.append(key)
        groups[key]["items"].append(it)

    for g in groups.values():
        has_ep = any(_ep_key(it.get("title", ""))[0] != 99 for it in g["items"])
        if has_ep:
            best = next((it.get("kind") for it in g["items"]
                         if (it.get("kind") or "").startswith("tvshow")), "tvshow")
            g["kind"] = best
        g["items"].sort(key=lambda it: (_ep_key(it.get("title", "")),
                                        (it.get("title") or "").lower()))
    return [groups[k] for k in order]


def _extract_series_name(title):
    """Extrae nombre base de serie limpiando marcas de calidad/episodio.

    'Separacion [HDTV 1080p][Cap.201]'       -> 'Separacion'
    'The Last of Us 1x03 [720p]'              -> 'The Last of Us'
    'Arcane [4K 2160p][Cap.101]'              -> 'Arcane'
    'Separacion - Temporada 1 [HDTV 1080p]'   -> 'Separacion'
    'La Casa del Dragon T2 [1080p]'           -> 'La Casa del Dragon'
    """
    t = title or ""
    # Quitar todo entre corchetes
    t = re.sub(r"\[.*?\]", "", t)
    # Quitar todo entre paréntesis con contenido técnico
    t = re.sub(r"\((?:720p|1080p|2160p|4[Kk]|HDRip|HDTV|Bluray|MicroHD|"
               r"WEB-?DL|DVDRip|BDRemux|Remux)[^)]*\)", "", t, flags=re.I)
    # Quitar "- Temporada N", "- Nª Temporada", "Temporada N"
    # Cubre: "Temporada 1", "1ª Temporada", "1a Temporada", "- 2º Temporada"
    t = re.sub(r"\s*-?\s*[Tt]emporada\s+\d+", "", t)
    t = re.sub(r"\s*-?\s*\d+[ªºaAoO]?\s*[Tt]emporada\b", "", t)
    # Quitar "T1", "T2" etc. (abreviatura española de temporada)
    t = re.sub(r"\s+T\d{1,2}\b", "", t)
    # Quitar patrones de episodio: Cap.NNN, SxxExx, NxNN
    t = re.sub(r"\b[Cc]ap\.?\s*\d+", "", t)
    t = re.sub(r"\b[Ss]\d{1,2}[Ee]\d{1,3}\b", "", t)
    t = re.sub(r"\b\d{1,2}x\d{2,3}\b", "", t)
    # Quitar año entre paréntesis
    t = re.sub(r"\(\d{4}\)", "", t)
    # Quitar calidades sueltas
    t = re.sub(r"\b(?:720p|1080p|2160p|4[Kk]|HDRip|HDTV|Bluray|BluRay|"
               r"MicroHD|WEB-?DL|DVDRip|BDRemux|Remux)\b",
               "", t, flags=re.IGNORECASE)
    # Limpiar separadores y espacios residuales
    t = re.sub(r"[\s\-–_.]+$", "", t)
    t = re.sub(r"\s{2,}", " ", t).strip()
    return t


def _cache_series_groups(cache_key, groups):
    """Guarda los grupos de series en Window properties de Kodi.

    Las Window properties persisten entre invocaciones del plugin
    dentro de la misma sesion de Kodi — exactamente lo que necesitamos
    para que el usuario pueda entrar en un grupo desde search().
    """
    data = {}
    for sname, items_list in groups.items():
        data[sname] = [
            {"title": it.get("title", ""), "url": it.get("url", ""),
             "kind": it.get("kind", ""), "source": it.get("source", ""),
             "thumb": it.get("thumb", ""), "image": it.get("image", ""),
             "quality": it.get("quality", "")}
            for it in items_list
        ]
    try:
        win = xbmcgui.Window(10000)
        win.setProperty(f"mw_sg_{cache_key}", json.dumps(data))
    except Exception as e:
        xbmc.log(f"[MejorWolf] cache_series_groups error: {e}",
                 xbmc.LOGWARNING)


def _get_cached_series_group(cache_key, series_name):
    """Recupera items de un grupo de series desde la cache."""
    try:
        win = xbmcgui.Window(10000)
        raw = win.getProperty(f"mw_sg_{cache_key}")
        if not raw:
            return []
        data = json.loads(raw)
        return data.get(series_name, [])
    except Exception:
        return []


def search(filter_kind=None):
    """Busqueda combinada en las 3 fuentes (pide texto con el teclado)."""
    # Prerellenar con la ultima busqueda (comodidad)
    kb = xbmc.Keyboard(_last_search_load(), "Buscar en MejorWolf")
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(HANDLE)
        return
    q = kb.getText().strip()
    if not q:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    _run_search(q, filter_kind)


def remote_search(q, filter_kind=None):
    """Busqueda lanzada desde el Teclado Remoto (movil): q ya viene dada."""
    q = (q or "").strip()
    if not q:
        xbmcplugin.endOfDirectory(HANDLE)
        return
    _run_search(q, filter_kind)


def remote_kb_screen():
    """Muestra el codigo de 6 cifras + un QR para vincular el movil.

    El usuario escanea el QR (o entra en la web y teclea el codigo). El
    servicio en segundo plano ya esta sondeando: cuando el movil envia una
    busqueda, aparece sola en la tele.
    """
    code = rkb.get_code()
    qr = rkb.qr_url()
    web = rkb.relay_base() + "/kb" if rkb.relay_base() else ""

    code_spaced = "  ".join(code)   # "1  2  3  4  5  6" se lee mejor
    txt = (
        "Controla MejorWolf desde tu móvil.\n\n"
        "[B]1[/B]   Escanea el QR con la cámara del móvil.\n"
        "[COLOR grey]      o entra en[/COLOR]  [COLOR cyan]%s[/COLOR]\n\n"
        "[B]2[/B]   Introduce este código para vincular:\n"
        "      [COLOR yellow][B]%s[/B][/COLOR]\n\n"
        "[B]3[/B]   Pulsa [B]Atrás[/B] en el mando para CERRAR esta pantalla.\n"
        "[COLOR grey]      (si buscas con esta pantalla abierta, el resultado\n"
        "      queda detrás y no lo verás)[/COLOR]\n\n"
        "[B]4[/B]   Listo. Busca y controla desde el móvil estés donde estés:\n"
        "      la búsqueda aparece sola en la tele.\n\n"
        "[COLOR grey]Solo hay que vincular una vez por dispositivo.[/COLOR]"
        % (web or "(configura el relay en Ajustes)", code_spaced)
    )

    panel_tex = os.path.join(ADDON_PATH, "resources", "media", "white.png")

    class _KBWin(xbmcgui.WindowDialog):
        def __init__(self):
            super().__init__()
            w, h = 1280, 720
            # Fondo (fanart del addon, fichero real)
            try:
                self.addControl(xbmcgui.ControlImage(0, 0, w, h, FANART))
            except Exception:
                pass
            # Panel oscuro semitransparente detras del texto (legibilidad).
            # Base blanca tintada con colorDiffuse AARRGGBB (E6 ~ 90% opaco).
            try:
                self.addControl(xbmcgui.ControlImage(
                    40, 30, 700, 670, panel_tex, colorDiffuse="0xE60D1117"))
            except Exception:
                pass
            self.addControl(xbmcgui.ControlLabel(
                80, 50, 620, 50, "[B]Teclado Remoto[/B]",
                textColor="0xFFFFFFFF", font="font30"))
            if qr:
                self.addControl(xbmcgui.ControlImage(770, 150, 400, 400, qr))
            self._tb = xbmcgui.ControlTextBox(
                80, 150, 640, 520, font="font13", textColor="0xFFFFFFFF")
            self.addControl(self._tb)
            self._tb.setText(txt)

        def onAction(self, action):
            if action.getId() in (9, 10, 92):   # parent/back/nav-back
                self.close()

    try:
        win = _KBWin()
        win.doModal()
        del win
    except Exception as e:
        xbmc.log(f"[MejorWolf] remote_kb_screen error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "Teclado Remoto",
            f"Entra en {web} en el móvil y escribe el código:\n\n"
            f"[B]{code_spaced}[/B]\n\nLuego escribe tu búsqueda y pulsa Buscar.")


def _run_search(q, filter_kind=None):
    """Ejecuta la busqueda combinada para una query `q` ya dada.

    Lo usan tanto el teclado normal como el Teclado Remoto (movil).
    Muestra resultados de DonTorrent, EliteTorrent y WolfMax4K.
    Las series de TODAS las fuentes se agrupan por nombre (como Tacones).
    """
    _last_search_save(q)

    # Buscar en paralelo en las 3 fuentes con hilos DAEMON.
    # CLAVE: usar hilos daemon (no ThreadPoolExecutor) para que un hilo
    # lento/colgado (p.ej. relay frio) NUNCA bloquee el cierre y congele
    # la busqueda. La busqueda devuelve EXACTAMENTE en el deadline de cada
    # fuente pase lo que pase con los rezagados.
    import threading
    all_items = []
    source_counts = {}
    _results = {}                  # label -> [items]
    _events = {lbl: threading.Event() for lbl in ("DT", "ET", "WF", "DX")}

    def _search_src(label, fn):
        try:
            res = fn(q) or []
        except Exception as e:
            res = []
            xbmc.log(f"[MejorWolf] search {label} ERROR: {e}",
                     xbmc.LOGWARNING)
            import traceback
            xbmc.log(f"[MejorWolf] search {label} traceback: "
                     f"{traceback.format_exc()}", xbmc.LOGWARNING)
        _results[label] = res
        source_counts[label] = len(res)
        xbmc.log(f"[MejorWolf] search {label}: {len(res)} resultados",
                 xbmc.LOGINFO)
        _events[label].set()

    # 1) Lanzamos YA los hilos (la propia peticion de DT despierta el relay).
    start = time.time()
    for lbl, fn in (("DT", dt.search), ("ET", et.search), ("WF", wf.search),
                    ("DX", dx.search)):
        threading.Thread(target=_search_src, args=(lbl, fn),
                         daemon=True).start()

    # 2) En PARALELO sondeamos el calor del relay para decidir cuanto esperar
    # a DonTorrent. CLAVE: el deadline es un MAXIMO, no una espera fija -> en
    # cuanto DT responde salimos. Con el relay CALIENTE (DT ~2-3s) un deadline
    # alto NO cuesta nada; solo en FRIO (relay dormido, free tier de Render)
    # esperamos mas para que DonTorrent llegue (es innegociable). El sondeo
    # corre solapado con los hilos, asi que no añade latencia en caliente.
    try:
        warmth = dt.relay_warmth(timeout=3.0)
    except Exception:
        warmth = "warm"
    if warmth == "cold":
        dt_to = 55     # relay despertando (~50s): dale tiempo, DT debe salir
    elif warmth == "down":
        dt_to = 10     # relay no disponible: no esperes de balde
    else:
        dt_to = 7      # caliente: DT responde ~2-4s; 7 da margen sin pasarnos

    # Deadline POR FUENTE. Objetivo: en CALIENTE la busqueda cierra en 5-7s.
    # El deadline es un MAXIMO para rezagados; en cuanto las 4 responden salimos
    # (lo normal son ~5s). DT lleva el margen mayor (innegociable); ET/WF/DX no
    # deben hacer esperar mas de ~6-7s. En FRIO solo esperamos a DT (raro: el
    # relay se mantiene caliente con auto-ping).
    PER_SOURCE_TIMEOUT = {"DT": dt_to, "ET": 6, "WF": 6, "DX": 7}

    # Diálogo de carga CENTRADO con barra de %. Va mostrando el estado de cada
    # fuente en vivo y se puede cancelar. No penaliza la velocidad: las fuentes
    # corren en hilos aparte; aqui solo refrescamos la UI cada 0.2s.
    NAMES = {"DT": "DonTorrent", "ET": "EliteTorrent", "WF": "WolfMax4K",
             "DX": "DivxTotal"}
    dlg = None
    try:
        dlg = xbmcgui.DialogProgress()
        dlg.create(f"MejorWolf · {q}", "Buscando...")
    except Exception:
        dlg = None

    max_deadline = max(PER_SOURCE_TIMEOUT.values())
    done = set()
    done_time = {}          # lbl -> segundos que tardo en completarse
    try:
        while True:
            now = time.time()
            elapsed = now - start
            for lbl in ("DT", "ET", "WF", "DX"):
                if lbl in done:
                    continue
                if _events[lbl].is_set():
                    all_items.extend(_results.get(lbl, []))
                    done.add(lbl)
                    done_time[lbl] = elapsed
                elif elapsed >= PER_SOURCE_TIMEOUT[lbl]:
                    source_counts[lbl] = -1
                    done.add(lbl)
                    done_time[lbl] = elapsed
                    xbmc.log(f"[MejorWolf] search {lbl}: TIMEOUT "
                             f"{PER_SOURCE_TIMEOUT[lbl]}s (relay frio?)",
                             xbmc.LOGWARNING)
            if dlg is not None:
                # % combina fuentes completadas y tiempo transcurrido
                pct = max(int(len(done) / 4.0 * 100),
                          int(min(95, elapsed / max_deadline * 90)))
                pct = min(99, pct) if len(done) < 4 else 100
                # OJO: DialogProgress solo muestra ~4 lineas. Con 4 fuentes NO
                # cabe ademas una cabecera aparte (cortaba la 5a linea =
                # DivxTotal). Solucion: 1 linea por fuente (4 justas), el tiempo
                # pegado a cada fuente en curso y la query va en el TITULO.
                lines = []
                for lbl in ("DT", "ET", "DX", "WF"):
                    nm = NAMES[lbl]
                    if lbl not in done:
                        base = ("despertando" if (warmth == "cold"
                                and lbl == "DT") else "buscando")
                        estado = f"{base}... {elapsed:.0f}s"
                    elif source_counts.get(lbl, 0) >= 0:
                        n = len(_results.get(lbl, []))
                        estado = f"listo ({n}) en {done_time[lbl]:.1f}s"
                    else:
                        estado = f"sin respuesta ({done_time[lbl]:.0f}s)"
                    lines.append(f"{nm}: {estado}")
                try:
                    dlg.update(pct, "\n".join(lines))
                except Exception:
                    pass
                if dlg.iscanceled():
                    break
            if len(done) == 4:
                break
            if elapsed > max_deadline + 1:
                break
            xbmc.sleep(200)
    finally:
        if dlg is not None:
            try:
                dlg.update(100)
                dlg.close()
            except Exception:
                pass

    total_elapsed = time.time() - start
    xbmc.log(f"[MejorWolf] search totals: DT={source_counts.get('DT',0)} "
             f"ET={source_counts.get('ET',0)} WF={source_counts.get('WF',0)} "
             f"DX={source_counts.get('DX',0)} "
             f"total_raw={len(all_items)} en {total_elapsed:.1f}s", xbmc.LOGINFO)
    # Aviso breve con el tiempo total (para tener controlado el rendimiento)
    try:
        xbmcgui.Dialog().notification(
            "MejorWolf", f"Búsqueda en {total_elapsed:.1f}s",
            xbmcgui.NOTIFICATION_INFO, 2500)
    except Exception:
        pass

    # ── Filtrar por tipo (movie / tvshow) ─────────────────────────────
    if filter_kind:
        base_fk = filter_kind.split("_")[0]   # "movie" / "tvshow"
        all_items = [i for i in all_items
                     if (i.get("kind") or "movie").startswith(base_fk)]

    # Deduplicar por URL
    seen, items = set(), []
    for it in all_items:
        u = it.get("url", "")
        if u not in seen:
            seen.add(u)
            items.append(it)

    xbmc.log(f"[MejorWolf] search '{q}' -> {len(items)} resultados unicos",
             xbmc.LOGINFO)

    if not items:
        _error(f"Sin resultados para: {q}",
               xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    # ── Resultados organizados por fuente ────────────────────────────
    # Nivel 1: una carpeta por fuente con su contador
    #   DonTorrent (12 resultados)
    #   EliteTorrent (25 resultados)
    #   WolfMax4K (8 resultados)
    # Dentro de cada carpeta: peliculas y series agrupadas por nombre.
    cache_key = re.sub(r"[^a-zA-Z0-9]", "_", q.lower())[:40]
    by_source = {"dt": [], "et": [], "wf": [], "dx": []}
    for it in items:
        src = it.get("source", "dt")
        by_source.setdefault(src, []).append(it)

    # Cache items por fuente para que show_source_results los recupere
    _cache_source_items(cache_key, by_source)

    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.setPluginCategory(HANDLE, f"Búsqueda: {q}")

    # Orden: DT primero (mas catalogo), luego ET, luego WF
    order = [("dt", "DonTorrent"), ("et", "EliteTorrent"),
             ("dx", "DivxTotal"), ("wf", "WolfMax4K")]
    for src, src_label in order:
        src_items = by_source.get(src, [])
        if not src_items:
            continue
        n = len(src_items)
        label = f"{src_label}  ({n} resultados)"
        action_url = _u(action="source_results", src=src,
                       cache_key=cache_key, q=q)
        # Usar icono basado en tipo dominante
        movies = sum(1 for i in src_items
                     if not (i.get("kind", "movie").startswith("tvshow")))
        is_movies_dominant = movies > n / 2
        icon = IC["movie"] if is_movies_dominant else IC["tvshow"]
        li = _li(label, info={"title": label, "plot": f"{n} resultados de "
                              f"'{q}' en {src_label}"}, icon=icon)
        xbmcplugin.addDirectoryItem(HANDLE, action_url, li, isFolder=True)

    xbmc.log(f"[MejorWolf] search display: {sum(len(v) for v in by_source.values())} "
             f"items en {sum(1 for v in by_source.values() if v)} fuentes",
             xbmc.LOGINFO)
    xbmcplugin.endOfDirectory(HANDLE)


def _cache_source_items(cache_key, by_source):
    """Cachea items por fuente en Window properties."""
    data = {}
    for src, src_items in by_source.items():
        data[src] = [
            {"title": it.get("title", ""), "url": it.get("url", ""),
             "kind": it.get("kind", ""), "source": it.get("source", ""),
             "thumb": it.get("thumb", ""), "image": it.get("image", ""),
             "quality": it.get("quality", "")}
            for it in src_items
        ]
    try:
        win = xbmcgui.Window(10000)
        win.setProperty(f"mw_src_{cache_key}", json.dumps(data))
    except Exception as e:
        xbmc.log(f"[MejorWolf] cache_source_items error: {e}",
                 xbmc.LOGWARNING)


def _get_cached_source_items(cache_key, src):
    """Recupera items de una fuente desde la cache."""
    try:
        win = xbmcgui.Window(10000)
        raw = win.getProperty(f"mw_src_{cache_key}")
        if not raw:
            return []
        data = json.loads(raw)
        return data.get(src, [])
    except Exception:
        return []


def show_source_results(src, cache_key, q=""):
    """Muestra los resultados de una fuente concreta.

    Dentro de cada fuente:
      - Peliculas/documentales: individuales con su titulo y portada TMDB
      - Series: agrupadas por nombre base (estilo Tacones)
    """
    items_data = _get_cached_source_items(cache_key, src)

    # Si cache miss y tenemos query, re-buscar SOLO esa fuente
    if not items_data and q:
        xbmc.log(f"[MejorWolf] source_results: cache miss, re-buscando "
                 f"{src} '{q}'", xbmc.LOGINFO)
        scraper_map = {"dt": dt, "et": et, "wf": wf, "dx": dx}
        scraper = scraper_map.get(src)
        if scraper:
            try:
                items_data = scraper.search(q) or []
            except Exception as e:
                xbmc.log(f"[MejorWolf] re-search {src} error: {e}",
                         xbmc.LOGERROR)

    if not items_data:
        _error(f"Sin resultados en {SOURCE_LABEL.get(src, src)}",
               xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    src_label = SOURCE_LABEL.get(src, src)
    xbmcplugin.setPluginCategory(HANDLE, f"{src_label}: {q}")

    # Separar individuales (peliculas/docs) de series agrupables.
    # Un item es "agrupable como serie" si:
    #   a) su kind es tvshow, O
    #   b) su titulo tiene marca de capitulo/episodio (Cap.N, SxxExx, NxNN).
    # Esto cubre documentales/series de WolfMax cuya URL /online/<id> se
    # clasifica como "movie" pero que en realidad son capitulos (ej. "Rafa").
    _CAP_MARK = re.compile(
        r"\b[Cc]ap\.?\s*\d+|\b[Ss]\d{1,2}[Ee]\d{1,3}\b|\b\d{1,2}x\d{2,3}\b",
        re.IGNORECASE)
    individual = []
    series_groups = {}
    for it in items_data:
        kind = it.get("kind", "movie")
        title = it.get("title", "")
        is_episode = kind.startswith("tvshow") or bool(_CAP_MARK.search(title))
        if is_episode:
            sname = _extract_series_name(title)
            if sname:
                series_groups.setdefault(sname, []).append(it)
            else:
                individual.append(it)
        else:
            individual.append(it)

    # Grupos de 1 item → individual
    multi_groups = {}
    for sname, group_items in series_groups.items():
        if len(group_items) == 1:
            individual.append(group_items[0])
        else:
            multi_groups[sname] = group_items

    # Cachear grupos para series_group action (reutiliza el sistema existente)
    if multi_groups:
        sg_key = f"{cache_key}_{src}"
        _cache_series_groups(sg_key, multi_groups)
    else:
        sg_key = cache_key

    # Ordenar por CALIDAD (mejor primero) — SOLO en busquedas. Agrupamos por
    # titulo base para que las versiones de la misma peli queden juntas y, en
    # cada una, la mejor calidad arriba. (En Estrenos/Cine NO se ordena: alli
    # interesa el orden por fecha/recientes.)
    individual.sort(key=lambda it: (
        _norm_for_group(_series_base(it.get("title", ""))),
        -_quality_rank(it),
    ))

    # Enriquecer con TMDB
    enriched_ind = _enrich_many(individual) if individual else []
    group_list = list(multi_groups.items())
    group_reps = [g[0] for g in (v for _, v in group_list)] if group_list else []
    enriched_groups = _enrich_many(group_reps) if group_reps else []

    # Determinar tipo de contenido
    has_movies = any(_media_type(it.get("kind", "movie")) == "movie"
                     for it in items_data)
    has_tvshows = any(_media_type(it.get("kind", "movie")) == "tvshow"
                      for it in items_data)
    if has_tvshows and not has_movies:
        xbmcplugin.setContent(HANDLE, "tvshows")
    elif has_movies and not has_tvshows:
        xbmcplugin.setContent(HANDLE, "movies")
    else:
        xbmcplugin.setContent(HANDLE, "videos")

    # Mostrar items individuales
    for it, (info, art) in zip(individual, enriched_ind):
        label = info["title"]
        kind = it.get("kind", "movie")
        action_url = _u(action="detail", src=src, url=it["url"],
                       kind=kind, title=it["title"])
        xbmcplugin.addDirectoryItem(
            HANDLE, action_url,
            _li(label, info=info, art=art),
            isFolder=True)

    # Mostrar series agrupadas (carpeta por serie con N caps)
    for (sname, group_items), (info, art) in zip(group_list, enriched_groups):
        n = len(group_items)
        label = f"{sname}  ({n} resultados)"
        action_url = _u(action="series_group", series_name=sname,
                       cache_key=f"{cache_key}_{src}", q=q)
        li = _li(label, info=dict(info, title=label,
                                  mediatype="tvshow"), art=art)
        xbmcplugin.addDirectoryItem(HANDLE, action_url, li, isFolder=True)

    xbmc.log(f"[MejorWolf] source_results {src}: "
             f"{len(individual)} individuales + {len(group_list)} series",
             xbmc.LOGINFO)
    xbmcplugin.endOfDirectory(HANDLE)


def show_series_group(series_name, cache_key, q=""):
    """Muestra los items individuales de un grupo de series.

    Cuando el usuario entra en una carpeta de serie agrupada,
    ve todos los resultados de esa serie (temporadas, capitulos)
    de todas las fuentes, cada uno con su enlace de detalle.
    """
    items_data = _get_cached_series_group(cache_key, series_name)

    if not items_data:
        # Cache expirada o perdida: re-buscar y filtrar
        xbmc.log(f"[MejorWolf] series_group: cache miss, re-buscando '{q}'",
                 xbmc.LOGINFO)
        if q:
            re_items = []
            try:
                with ThreadPoolExecutor(max_workers=3) as ex:
                    futs = [
                        ex.submit(lambda: dt.search(q) or []),
                        ex.submit(lambda: et.search(q) or []),
                        ex.submit(lambda: wf.search(q) or []),
                    ]
                    for fut in futs:
                        re_items.extend(fut.result() or [])
            except Exception:
                pass
            items_data = []
            for it in re_items:
                kind = it.get("kind", "movie")
                if kind.startswith("tvshow"):
                    sname = _extract_series_name(it.get("title", ""))
                    if sname == series_name:
                        items_data.append(it)

    if not items_data:
        _error(f"No se encontraron resultados para: {series_name}",
               xbmcgui.NOTIFICATION_WARNING, 4000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    xbmcplugin.setPluginCategory(HANDLE, series_name)
    xbmcplugin.setContent(HANDLE, "tvshows")

    # Ordenar por capitulo/episodio (Cap.101, 102... o SxxExx). Asi los
    # capitulos salen 1x01, 1x02... en orden y no revueltos.
    items_data = sorted(items_data,
                        key=lambda it: _ep_key(it.get("title", "")))

    # Todos los capitulos son la MISMA serie -> enriquecer TMDB UNA sola vez
    # (con el primer item) y reusar portada/info para todos. Evita N llamadas
    # TMDB (4 caps de Rafa = 1 llamada en vez de 4 -> mucho mas rapido).
    shared_info, shared_art = _enrich_one(items_data[0])

    for it in items_data:
        src = it.get("source", "dt")
        src_tag = SOURCE_LABEL.get(src, src)
        quality = it.get("quality", "")
        quality_tag = f" [{quality}]" if quality else ""

        raw_title = it.get("title", series_name)
        url = it.get("url", "")
        kind = it.get("kind", "tvshow")
        info = dict(shared_info)
        art = shared_art

        # Etiqueta: si detectamos numero de capitulo, mostrar "Cap. N" claro
        s, e = _ep_key(raw_title)
        if e != 99:
            cap_label = f"Cap. {e}" if s in (1, 99) else f"{s}x{e:02d}"
            label = f"{cap_label}{quality_tag}  ({src_tag})"
        else:
            label = f"{raw_title}{quality_tag}  ({src_tag})"

        # WolfMax: si la URL ya es un capitulo reproducible (/online/<id>),
        # vamos DIRECTO a reproducir (no re-buscar la serie -> evita 40s).
        if src == "wf":
            if re.search(r"/(online|movie|capitulo|episodio)/\d+", url):
                action_url = _u(action="detail", src="wf", url=url,
                               kind=kind, title=raw_title)
            else:
                action_url = _u(action="wf_series", q=raw_title,
                               seed_url=url, title=series_name)
        else:
            action_url = _u(action="detail", src=src, url=url,
                           kind=kind, title=raw_title)

        xbmcplugin.addDirectoryItem(
            HANDLE, action_url,
            _li(label, info=dict(info, title=label), art=art),
            isFolder=True)

    xbmc.log(f"[MejorWolf] series_group '{series_name}': "
             f"{len(items_data)} items", xbmc.LOGINFO)
    xbmcplugin.endOfDirectory(HANDLE)


# ── WolfMax: jerarquia Serie > Temporadas > Capitulos ──────────────────────

_SERIES_CACHE_DIR = None


def _series_cache_dir():
    global _SERIES_CACHE_DIR
    if _SERIES_CACHE_DIR is None:
        d = xbmcvfs.translatePath("special://temp/mejorwolf_cache/")
        os.makedirs(d, exist_ok=True)
        _SERIES_CACHE_DIR = d
    return _SERIES_CACHE_DIR


def _cache_key(q):
    import hashlib
    h = hashlib.md5(q.lower().strip().encode("utf-8")).hexdigest()[:12]
    return f"wf_series_{h}.json"


def _save_series_cache(q, data):
    try:
        path = os.path.join(_series_cache_dir(), _cache_key(q))
        payload = {"ts": time.time(), "q": q, "data": data}
        with open(path, "w", encoding="utf-8") as f:
            json.dump(payload, f, ensure_ascii=False)
    except Exception as e:
        xbmc.log(f"[MejorWolf] cache save err: {e}", xbmc.LOGWARNING)


def _load_series_cache(q, max_age=600):
    try:
        path = os.path.join(_series_cache_dir(), _cache_key(q))
        if not os.path.exists(path):
            return None
        with open(path, "r", encoding="utf-8") as f:
            payload = json.load(f)
        if time.time() - payload.get("ts", 0) > max_age:
            return None
        data = payload.get("data")
        if data and "seasons" in data:
            data["seasons"] = {int(k): v for k, v in data["seasons"].items()}
        return data
    except Exception as e:
        xbmc.log(f"[MejorWolf] cache load err: {e}", xbmc.LOGWARNING)
        return None


def wf_series(q, seed_url="", title=""):
    clean_q = _series_base(q) or q
    data = _load_series_cache(clean_q)
    if not data:
        progress = xbmcgui.DialogProgressBG()
        progress.create("MejorWolf", "Buscando todos los capítulos...")
        try:
            progress.update(20, "MejorWolf", "Buscando y expandiendo...")
            expanded = wf.search_and_expand(clean_q)
            data = {
                "title":   expanded.get("title", title or clean_q),
                "image":   expanded.get("image"),
                "seasons": expanded.get("seasons", {}),
                "total":   sum(len(v) for v in expanded.get("seasons", {}).values()),
            }
        except Exception as e:
            xbmc.log(f"[MejorWolf] wf_series error: {e}", xbmc.LOGERROR)
            data = {"title": title or clean_q, "image": None, "seasons": {}, "total": 0}
        finally:
            try:
                progress.close()
            except Exception:
                pass
        _save_series_cache(clean_q, data)

    seasons = data.get("seasons", {})
    series_title = data.get("title") or title or q

    if not seasons:
        _error(f"No se encontraron capítulos para: {q}",
               xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    meta = tmdb.enrich(series_title, kind="tv")
    art = _build_art(meta, data)
    xbmcplugin.setPluginCategory(HANDLE, series_title)

    if len(seasons) == 1:
        s_num = list(seasons.keys())[0]
        _show_season_episodes(seasons[s_num], series_title, s_num, art, meta)
        return

    xbmcplugin.setContent(HANDLE, "seasons")
    for s_num in sorted(seasons.keys()):
        eps = seasons[s_num]
        n = len(eps)
        label = f"Temporada {s_num}  ({n} capítulo{'s' if n != 1 else ''})"
        info = {
            "title": label, "plot": meta.get("plot"),
            "year": meta.get("year"), "mediatype": "season",
        }
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _u(action="wf_season", q=clean_q, season=str(s_num),
               title=series_title, seed_url=seed_url),
            _li(label, info=info, art=art),
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(HANDLE)


def wf_season(q, season, title="", seed_url=""):
    s_num = int(season)
    clean_q = _series_base(q) or q
    data = _load_series_cache(clean_q)
    if not data:
        progress = xbmcgui.DialogProgressBG()
        progress.create("MejorWolf", f"Cargando Temporada {s_num}...")
        try:
            expanded = wf.search_and_expand(clean_q)
            data = {
                "title":   expanded.get("title", title or clean_q),
                "image":   expanded.get("image"),
                "seasons": expanded.get("seasons", {}),
                "total":   sum(len(v) for v in expanded.get("seasons", {}).values()),
            }
            _save_series_cache(clean_q, data)
        except Exception as e:
            xbmc.log(f"[MejorWolf] wf_season error: {e}", xbmc.LOGERROR)
            data = {"title": title or clean_q, "image": None, "seasons": {}}
        finally:
            try:
                progress.close()
            except Exception:
                pass

    episodes = data.get("seasons", {}).get(s_num, [])
    series_title = data.get("title") or title or q

    if not episodes:
        _error(f"Sin capítulos de la temporada {s_num}",
               xbmcgui.NOTIFICATION_WARNING, 5000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    meta = tmdb.enrich(series_title, kind="tv")
    art = _build_art(meta, data)
    _show_season_episodes(episodes, series_title, s_num, art, meta)


def _show_season_episodes(episodes, series_title, s_num, art, meta):
    xbmcplugin.setPluginCategory(HANDLE, f"{series_title} - Temporada {s_num}")
    xbmcplugin.setContent(HANDLE, "episodes")
    for ep in episodes:
        e_num = ep.get("episode", 0)
        quality = ep.get("quality") or ""
        ep_title = ep.get("title", "")
        label = f"{s_num}x{e_num:02d}"
        clean = re.sub(r"\[.*?\]|\(.*?\)", "", ep_title).strip()
        base_norm = re.sub(r"\s+", " ", series_title.lower().strip())
        clean_norm = re.sub(r"\s+", " ", clean.lower().strip())
        if clean_norm.startswith(base_norm):
            clean = clean[len(series_title):].strip(" -:|")
        if clean and clean.lower() != series_title.lower():
            label = f"{label} - {clean}"
        if quality:
            label = f"{label} [{quality}]"
        ep_art = dict(art)
        if ep.get("image"):
            ep_art["thumb"] = ep["image"]
        info = {
            "title": label, "tvshowtitle": series_title,
            "plot": meta.get("plot"), "year": meta.get("year"),
            "mediatype": "episode", "season": s_num, "episode": e_num,
        }
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _u(action="detail", src="wf", url=ep["url"],
               kind="tvshow", title=ep_title),
            _li(label, info=info, art=ep_art),
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(HANDLE)


# ── WolfMax: A-Z e Indice ──────────────────────────────────────────────────

def wf_az_menu(filter_kind=None, letter=None):
    label_kind = {"movie": "Películas", "tvshow": "Series"}.get(filter_kind, "Todo")
    if not letter:
        xbmcplugin.setPluginCategory(HANDLE, f"A-Z {label_kind}")
        letters = wf.az_letters(kind_filter=filter_kind)
        if not letters:
            xbmcgui.Dialog().ok(
                "MejorWolf",
                "El indice esta vacio. Ejecuta 'Reconstruir indice' "
                "desde Ajustes, o navega un poco por los listados.",
            )
            xbmcplugin.endOfDirectory(HANDLE)
            return
        for letra, count in letters:
            xbmcplugin.addDirectoryItem(
                HANDLE,
                _u(action="wf_az", filter_kind=filter_kind, letter=letra),
                _li(f"{letra}   ({count})", icon=IC["tvshow"]),
                isFolder=True,
            )
        xbmcplugin.endOfDirectory(HANDLE)
        return

    xbmcplugin.setPluginCategory(HANDLE, f"{label_kind} - {letter}")
    items = wf.browse_az(letter, kind_filter=filter_kind)
    if not items:
        _error(f"Sin items para '{letter}'", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    enriched = _enrich_many(items)
    for it, (info, art) in zip(items, enriched):
        xbmcplugin.addDirectoryItem(
            HANDLE,
            _u(action="detail", src="wf", url=it["url"],
               kind=it["kind"], title=it["title"]),
            _li(info["title"], info=info, art=art),
            isFolder=True,
        )
    xbmcplugin.setContent(HANDLE,
                          "movies" if filter_kind == "movie" else "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)


def wf_rebuild_index():
    dlg = xbmcgui.Dialog()
    if not dlg.yesno(
            "MejorWolf",
            "Recorrer los listados de WolfMax (pelis, series y\n"
            "documentales) para el índice A-Z. Tarda un minuto.\n¿Continuar?"):
        return
    progress = xbmcgui.DialogProgress()
    progress.create("MejorWolf", "Preparando reconstruccion...")
    state = {"cancel": False}

    def cb(done, total, current):
        if progress.iscanceled():
            state["cancel"] = True
            return True
        pct = int(done * 100 / total) if total else 0
        progress.update(pct, f"Procesando {done}/{total}\n[{current[:80]}]")
        return False

    try:
        added = wf.rebuild_index(progress_cb=cb)
    except Exception as e:
        xbmc.log(f"[MejorWolf] rebuild error: {e}", xbmc.LOGERROR)
        added = 0
    try:
        progress.close()
    except Exception:
        pass
    if state["cancel"]:
        _error(f"Cancelado. +{added} items", xbmcgui.NOTIFICATION_WARNING, 4000)
    else:
        total, _ = wf.index_stats()
        _error(f"Indice: +{added} nuevos, total {total}",
               xbmcgui.NOTIFICATION_INFO, 5000)


# ── Diagnostico ─────────────────────────────────────────────────────────────

def diagnose():
    xbmcplugin.setPluginCategory(HANDLE, "Diagnóstico")

    # Proxy
    ok, msg = hs.diagnose_proxy()
    line = f"Proxy Cloudflare: {msg}"
    xbmcplugin.addDirectoryItem(HANDLE, "", _li(line, icon=IC["help"]), isFolder=False)

    # DoH
    for label, status in dns_doh.diagnose_endpoints():
        xbmcplugin.addDirectoryItem(HANDLE, "", _li(f"{label}: {status}", icon=IC["help"]), isFolder=False)

    # Host resolution
    for host in ("www.wolfmax4k.com", "www.elitetorrent.com", dt.resolve_domain()):
        ips = dns_doh.resolve(host) or []
        line = f"DoH {host}: {', '.join(ips[:3]) if ips else 'sin respuesta'}"
        xbmcplugin.addDirectoryItem(HANDLE, "", _li(line, icon=IC["help"]), isFolder=False)

    # Site access
    targets = [
        ("DonTorrent", dt.base_url() + "/"),
        ("WolfMax4K",
         (ADDON.getSetting("wf_base_url") or "https://www.wolfmax4k.com").rstrip("/") + "/"),
        ("EliteTorrent",
         (ADDON.getSetting("et_base_url") or "https://www.elitetorrent.com").rstrip("/") + "/"),
    ]
    for label, url in targets:
        status, n, final, blocked = hs.diagnose(url)
        if blocked:
            line = f"{label}: {blocked} (HTTP {status})"
        elif status == 200 and n > 1000:
            line = f"{label}: OK (HTTP 200, {n} bytes)"
        else:
            line = f"{label}: HTTP {status}, {n} bytes"
        xbmcplugin.addDirectoryItem(HANDLE, "", _li(line, icon=IC["help"]), isFolder=False)

    # Quick scrape test
    samples = [
        ("DT peliculas", lambda: dt.latest("movie", 1)),
        ("DT series",    lambda: dt.latest("tvshow", 1)),
        ("ET estrenos",  lambda: et.latest("estrenos", 1)),
        ("ET peliculas", lambda: et.latest("movie", 1)),
        ("WF peliculas", lambda: wf.latest("movie", 1)),
    ]
    for label, fn in samples:
        try:
            result = fn()
            count = len(result[0]) if isinstance(result, tuple) else len(result or [])
            line = f"{label}: {count} items"
        except Exception as e:
            line = f"{label}: ERROR {e.__class__.__name__}"
        xbmcplugin.addDirectoryItem(HANDLE, "", _li(line, icon=IC["help"]), isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def open_settings():
    ADDON.openSettings()


# ── Router ──────────────────────────────────────────────────────────────────

def router(qs):
    params = dict(parse_qsl(qs))
    action = params.get("action")
    global _SNAP
    _SNAP = []
    try:
        if   action is None:            home()
        elif action == "home":          home()
        elif action == "estrenos":      estrenos()
        elif action == "section":       section(params["kind"])
        elif action == "src_movie":     src_section(params.get("src", "dt"), "movie")
        elif action == "src_tvshow":    src_section(params.get("src", "dt"), "tvshow")
        elif action == "documentales_menu": documentales_menu()
        elif action == "list":          list_items(params.get("src", "dt"),
                                                    params["kind"],
                                                    page=int(params.get("page", "1")))
        elif action == "et_genre":      et_genre(params["genre"],
                                                  page=int(params.get("page", "1")))
        elif action == "detail":        detail(params.get("src", "dt"),
                                               params["url"],
                                               params.get("kind", "movie"),
                                               params.get("title", ""))
        elif action == "play":          play(params.get("torrent", ""),
                                             params.get("t", ""))
        elif action == "dx_season":     dx_season(params.get("url", ""),
                                                  params.get("season", "1"),
                                                  params.get("title", ""))
        elif action == "dt_play":       dt_play(params.get("content_id", ""),
                                                 params.get("tabla", ""),
                                                 page_url=params.get("page_url", ""),
                                                 title=params.get("t", ""))
        elif action == "search":        search(filter_kind=params.get("filter_kind"))
        elif action == "remote_search": remote_search(params.get("q", ""))
        elif action == "remote_kb":
            remote_kb_screen()
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        elif action == "source_results": show_source_results(
                                            params.get("src", "dt"),
                                            params.get("cache_key", ""),
                                            q=params.get("q", ""))
        elif action == "series_group":  show_series_group(
                                            params.get("series_name", ""),
                                            params.get("cache_key", ""),
                                            q=params.get("q", ""))
        elif action == "wf_series":     wf_series(params.get("q", ""),
                                                   seed_url=params.get("seed_url", ""),
                                                   title=params.get("title", ""))
        elif action == "wf_season":     wf_season(params.get("q", ""),
                                                   params.get("season", "1"),
                                                   title=params.get("title", ""),
                                                   seed_url=params.get("seed_url", ""))
        elif action == "wf_az":         wf_az_menu(
                                            filter_kind=params.get("filter_kind"),
                                            letter=params.get("letter"))
        elif action == "wf_rebuild":    wf_rebuild_index()
        elif action == "generos_menu":  generos_menu()
        elif action == "settings":      open_settings()
        elif action == "diagnose":      diagnose()
        else:                           home()
        # Guardar la "foto" de la pantalla (por su ruta) para la vista Lista
        # del movil (solo si esta accion ha pintado items).
        if _SNAP:
            _snap_save(BASE + ("?" + qs if qs else ""))
    except Exception as e:
        import traceback
        xbmc.log(f"[MejorWolf] ROUTER ERROR: {e}\n{traceback.format_exc()}",
                 xbmc.LOGERROR)
        _error(f"Error: {e}")
        try:
            xbmcplugin.endOfDirectory(HANDLE)
        except Exception:
            pass
