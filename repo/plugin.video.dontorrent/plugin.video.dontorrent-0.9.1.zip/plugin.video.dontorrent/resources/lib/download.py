import hashlib
import json
from urllib.parse import quote, quote as urlquote, urlparse
import requests
import xbmc
import xbmcaddon
from . import domain
from . import anubis

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
TIMEOUT = 20
DIFFICULTY = 3  # leading hex zeros required by the site

API = "/api_validate_pow.php"

_ADDON = xbmcaddon.Addon()


def _proxy_base():
    raw = (_ADDON.getSetting("proxy_url") or "").strip().rstrip("/")
    return raw or None


def _proxy_force():
    return (_ADDON.getSetting("proxy_force") or "").lower() == "true"


def _anubis_cookies_for(url):
    """Return cached Anubis cookies for *url*'s domain.

    Handles the common case where cookies are cached under the canonical
    redirect domain (e.g. dontorrent.rocks) but the URL uses a different
    alias (e.g. dontorrent.irish).  We check the exact hostname first,
    then fall back to any cached dontorrent domain.
    """
    try:
        host = urlparse(url).hostname
        if not host:
            return {}
        cached = anubis.get_cached_cookies(host)
        if cached:
            return cached
        # Fallback: any cached dontorrent domain
        if "dontorrent" in host:
            for domain_key in list(anubis._cookie_cache.keys()):
                if "dontorrent" in domain_key:
                    c = anubis.get_cached_cookies(domain_key)
                    if c:
                        return c
        return {}
    except Exception:
        return {}


def _ensure_anubis_for(url):
    """Make sure we have valid Anubis cookies before making API calls."""
    cached = _anubis_cookies_for(url)
    if cached:
        return cached
    base = _proxy_base()
    if not base or not _proxy_force():
        return {}
    # Pre-flight GET to the domain root to trigger Anubis
    parsed = urlparse(url)
    root_url = f"{parsed.scheme}://{parsed.hostname}/"
    proxied = f"{base}/?u={urlquote(root_url, safe='')}"
    headers = {"User-Agent": UA, "Accept-Encoding": "identity"}
    try:
        xbmc.log(f"[download] Pre-flight GET to acquire Anubis cookies", xbmc.LOGINFO)
        r = requests.get(proxied, headers=headers, timeout=30)
        if anubis.is_anubis(r.text):
            init_cookies = {}
            for key, value in r.headers.items():
                if key.lower() == "set-cookie":
                    parts = value.split(";")
                    if "=" in parts[0]:
                        cn, cv = parts[0].split("=", 1)
                        cn, cv = cn.strip(), cv.strip()
                        if cn and cv:
                            init_cookies[cn] = cv
            for cn, cv in r.cookies.items():
                init_cookies[cn] = cv
            final = r.headers.get("x-mw-relay-final", root_url)
            anubis.solve_and_get_cookie(r.text, final, base, init_cookies=init_cookies)
    except Exception as exc:
        xbmc.log(f"[download] Pre-flight Anubis failed: {exc}", xbmc.LOGWARNING)
    return _anubis_cookies_for(url)


def _do_post(url, json_data, extra_headers=None):
    """POST JSON, routing through proxy when configured."""
    base = _proxy_base()
    headers = {
        "User-Agent": UA,
        "Content-Type": "application/json",
        "Accept": "application/json,*/*;q=0.8",
        "Accept-Encoding": "identity",
    }
    if extra_headers:
        headers.update(extra_headers)
    cached = _anubis_cookies_for(url)
    if not cached:
        cached = _ensure_anubis_for(url)
    if cached:
        headers["Cookie"] = "; ".join(f"{k}={v}" for k, v in cached.items())
    body = json.dumps(json_data)
    if base and _proxy_force():
        proxied = f"{base}/?u={urlquote(url, safe='')}"
        r = requests.post(proxied, data=body, headers=headers, timeout=30)
    else:
        r = requests.post(url, data=body, headers=headers, timeout=TIMEOUT)
    r.raise_for_status()
    return r


def _do_pow_via_worker(target_domain, json_data, cookies, referer=None):
    """POST to DonTorrent PoW API via the dedicated /dtpow worker endpoint.

    Two-phase protocol to bypass Anubis's per-method challenge:

      Phase 1 (optimistic): POST directly with existing cookies.
        If the POST gets an Anubis challenge, continue to Phase 2.

      Phase 2 (solve + retry): Solve the Anubis PoW from Phase 1's
        challenge, build the pass-challenge URL, and send it + the API
        data to /dtpow.  The worker submits the Anubis solution AND the
        POST within the SAME CF Worker isolate (same egress IP).

    Falls back to direct POST when no proxy is configured.
    """
    base = _proxy_base()
    if not base or not _proxy_force():
        url = f"https://{target_domain}{API}"
        headers = {
            "User-Agent": UA,
            "Content-Type": "application/json",
            "Accept": "application/json,*/*;q=0.8",
            "Accept-Encoding": "identity",
        }
        if cookies:
            headers["Cookie"] = "; ".join(f"{k}={v}" for k, v in cookies.items())
        r = requests.post(url, data=json.dumps(json_data),
                          headers=headers, timeout=TIMEOUT)
        r.raise_for_status()
        return r

    ref = referer or f"https://{target_domain}/"

    # --- Phase 1: optimistic POST through generic relay ---
    api_url = f"https://{target_domain}{API}"
    headers = {
        "User-Agent": UA,
        "Content-Type": "application/json",
        "Accept": "application/json,*/*;q=0.8",
        "Accept-Encoding": "identity",
    }
    if cookies:
        headers["Cookie"] = "; ".join(f"{k}={v}" for k, v in cookies.items())
    proxied = f"{base}/?u={urlquote(api_url, safe='')}"

    xbmc.log(f"[download] Phase 1: POST via relay -> {target_domain}, "
             f"action={json_data.get('action')}", xbmc.LOGINFO)
    r = requests.post(proxied, data=json.dumps(json_data),
                       headers=headers, timeout=30)

    # If the response is JSON, we're done (no Anubis challenge)
    if not anubis.is_anubis(r.text):
        xbmc.log(f"[download] Phase 1: Direct POST succeeded (no Anubis)",
                 xbmc.LOGINFO)
        r.raise_for_status()
        return r

    # --- Phase 2: solve Anubis PoW for the POST, then retry via /dtpow ---
    xbmc.log("[download] Phase 2: POST got Anubis challenge, solving PoW...",
             xbmc.LOGINFO)

    # Extract cookies from the challenge response
    post_init_cookies = dict(cookies or {})
    for k, v in r.headers.items():
        if k.lower() == "set-cookie":
            parts = v.split(";")
            if "=" in parts[0]:
                cn, cv = parts[0].split("=", 1)
                cn, cv = cn.strip(), cv.strip()
                if cn and cv:
                    post_init_cookies[cn] = cv
    for cn, cv in r.cookies.items():
        post_init_cookies[cn] = cv

    # Parse the Anubis challenge
    challenge_data = anubis._parse_challenge(r.text)
    if not challenge_data:
        raise RuntimeError("Could not parse Anubis challenge from POST")
    rules = challenge_data.get("rules", {})
    challenge_info = challenge_data.get("challenge", {})
    random_data = challenge_info.get("randomData", "")
    difficulty = rules.get("difficulty",
                           challenge_info.get("difficulty", 5))
    challenge_id = challenge_info.get("id", "")

    if not random_data or not challenge_id:
        raise RuntimeError("Anubis challenge missing randomData or id")

    # Solve the PoW
    hex_hash, nonce, elapsed = anubis._solve_pow(random_data, difficulty)
    elapsed_ms = int(elapsed * 1000)
    xbmc.log(f"[download] Phase 2: PoW solved in {elapsed:.2f}s "
             f"(nonce={nonce})", xbmc.LOGINFO)

    # Build pass-challenge URL
    pass_url = (
        f"https://{target_domain}"
        f"/.within.website/x/cmd/anubis/api/pass-challenge"
        f"?id={urlquote(challenge_id, safe='')}"
        f"&response={hex_hash}"
        f"&nonce={nonce}"
        f"&redir=/"
        f"&elapsedTime={elapsed_ms}"
    )

    # Send to /dtpow: pass-challenge + POST in one worker isolate
    endpoint = f"{base}/dtpow"
    payload = {
        "domain": target_domain,
        "api_data": json_data,
        "pass_challenge_url": pass_url,
        "cookies": post_init_cookies,
        "referer": ref,
    }
    xbmc.log("[download] Phase 2: Sending pass-challenge + POST to /dtpow",
             xbmc.LOGINFO)
    r2 = requests.post(endpoint, json=payload, headers={
        "User-Agent": UA,
        "Content-Type": "application/json",
        "Accept-Encoding": "identity",
    }, timeout=30)

    # Log diagnostic headers
    phase = r2.headers.get("x-mw-dt-phase", "?")
    post_st = r2.headers.get("x-mw-dt-post-status", "?")
    post_b = r2.headers.get("x-mw-dt-post-bytes", "?")
    still_anubis = r2.headers.get("x-mw-dt-post-anubis", "?")
    xbmc.log(f"[download] /dtpow result: phase={phase}, "
             f"POST={post_st} ({post_b}B), still_anubis={still_anubis}",
             xbmc.LOGINFO)

    if r2.headers.get("x-mw-dt-post-anubis") == "true":
        raise RuntimeError(
            "Anubis sigue bloqueando POST tras resolver PoW. "
            "Posible cambio en la proteccion del sitio."
        )

    r2.raise_for_status()
    return r2


def _do_get(url):
    """GET, routing through proxy when configured."""
    base = _proxy_base()
    headers = {"User-Agent": UA, "Accept-Encoding": "identity"}
    cached = _anubis_cookies_for(url)
    if not cached:
        cached = _ensure_anubis_for(url)
    if cached:
        headers["Cookie"] = "; ".join(f"{k}={v}" for k, v in cached.items())
    if base and _proxy_force():
        proxied = f"{base}/?u={urlquote(url, safe='')}"
        r = requests.get(proxied, headers=headers, timeout=30)
    else:
        r = requests.get(url, headers=headers, timeout=TIMEOUT)
    r.raise_for_status()
    return r


def _proof_of_work(challenge):
    target = "0" * DIFFICULTY
    nonce = 0
    while True:
        h = hashlib.sha256((challenge + str(nonce)).encode()).hexdigest()
        if h.startswith(target):
            return nonce
        nonce += 1


def resolve_torrent(content_id, tabla, page_url=None):
    """Run the site's PoW handshake to obtain the actual .torrent URL.

    Uses the /dtpow worker endpoint with a two-phase protocol:
    Phase 1 tries POST directly; if Anubis challenges, Phase 2 solves the
    PoW and submits the pass-challenge + POST within a single CF Worker
    isolate.
    """
    host = domain.resolve()
    base = f"https://{host}"
    referer = page_url or (base + "/")

    # Pre-fetch Anubis cookies (used as initial cookies for the POST)
    api_url = base + API
    cached = _anubis_cookies_for(api_url)
    if not cached:
        cached = _ensure_anubis_for(api_url)

    # 1) generate challenge
    r = _do_pow_via_worker(host, {
        "action": "generate",
        "content_id": int(content_id),
        "tabla": tabla,
    }, cached, referer)
    res = r.json()
    if not res.get("success"):
        raise RuntimeError(res.get("error") or "PoW: no challenge")
    challenge = res["challenge"]

    # 2) compute PoW
    nonce = _proof_of_work(challenge)

    # 3) validate and obtain download URL
    r = _do_pow_via_worker(host, {
        "action": "validate",
        "challenge": challenge,
        "nonce": nonce,
    }, cached, referer)
    res = r.json()
    if res.get("status") == "captcha_required":
        raise RuntimeError("DonTorrent pide captcha (limite alcanzado). Espera unos minutos.")
    if not res.get("success") or not res.get("download_url"):
        raise RuntimeError(res.get("error") or "PoW: validacion fallida")

    url = res["download_url"]
    if url.startswith("//"):
        url = "https:" + url
    elif url.startswith("/"):
        url = base + url
    return url


# --------------------------------------------------------------------------
# Bencode parser - minimal, just enough to read the file list of a .torrent.
# --------------------------------------------------------------------------

def _bencode(o):
    if isinstance(o, int):
        return f"i{o}e".encode()
    if isinstance(o, bytes):
        return f"{len(o)}:".encode() + o
    if isinstance(o, str):
        return _bencode(o.encode())
    if isinstance(o, list):
        return b"l" + b"".join(_bencode(x) for x in o) + b"e"
    if isinstance(o, dict):
        keys = sorted(o.keys())
        return b"d" + b"".join(_bencode(k) + _bencode(o[k]) for k in keys) + b"e"
    raise TypeError(type(o))


def _bdecode(data, i=0):
    c = data[i:i + 1]
    if c == b"i":
        end = data.index(b"e", i)
        return int(data[i + 1:end]), end + 1
    if c.isdigit():
        colon = data.index(b":", i)
        n = int(data[i:colon])
        start = colon + 1
        return data[start:start + n], start + n
    if c == b"l":
        i += 1
        out = []
        while data[i:i + 1] != b"e":
            v, i = _bdecode(data, i)
            out.append(v)
        return out, i + 1
    if c == b"d":
        i += 1
        out = {}
        while data[i:i + 1] != b"e":
            k, i = _bdecode(data, i)
            v, i = _bdecode(data, i)
            out[k] = v
        return out, i + 1
    raise ValueError(f"bad bencode at {i}: {c!r}")


# Common video extensions Elementum can stream directly without unpacking.
VIDEO_EXTS = {".mkv", ".mp4", ".avi", ".mov", ".m4v", ".wmv", ".flv", ".ts", ".m2ts", ".webm"}


def _build_magnet(decoded):
    """Build a magnet URI from a parsed .torrent dict, byte-perfect on the
    info hash (SHA1 over the re-encoded info dict, which is identical to
    the original because bencode dicts are sorted by key)."""
    if not isinstance(decoded, dict):
        return None
    info_dict = decoded.get(b"info")
    if not isinstance(info_dict, dict):
        return None
    info_hash = hashlib.sha1(_bencode(info_dict)).hexdigest()
    name = info_dict.get(b"name", b"")
    name = name.decode("utf-8", "replace") if isinstance(name, bytes) else ""
    trackers = []
    if isinstance(decoded.get(b"announce"), bytes):
        trackers.append(decoded[b"announce"].decode("utf-8", "replace"))
    al = decoded.get(b"announce-list")
    if isinstance(al, list):
        for tier in al:
            if isinstance(tier, list):
                for t in tier:
                    if isinstance(t, bytes):
                        trackers.append(t.decode("utf-8", "replace"))
    parts = [f"magnet:?xt=urn:btih:{info_hash}"]
    if name:
        parts.append("dn=" + quote(name, safe=""))
    seen = set()
    for t in trackers:
        if t in seen:
            continue
        seen.add(t)
        parts.append("tr=" + quote(t, safe=""))
    return "&".join(parts).replace("magnet:?&", "magnet:?", 1)


def inspect_torrent(url):
    """Download the .torrent and report whether it ships RAR archives, plus
    the largest video file (if any) and the total size. We use this to warn
    the user clearly before invoking Elementum, and to convert to magnet
    (which Elementum handles more reliably than https .torrent URLs)."""
    info = {
        "is_rar": False,
        "rar_parts": 0,
        "total_size": 0,
        "video_size": 0,
        "video_name": None,
        "name": None,
        "files": 0,
        "magnet": None,
    }
    try:
        r = _do_get(url)
        decoded, _ = _bdecode(r.content)
    except Exception:
        return info

    if not isinstance(decoded, dict):
        return info
    info["magnet"] = _build_magnet(decoded)
    meta = decoded.get(b"info") or {}
    name = meta.get(b"name")
    if isinstance(name, bytes):
        info["name"] = name.decode("utf-8", "replace")

    files = meta.get(b"files")
    flat = []
    if isinstance(files, list):
        for f in files:
            length = f.get(b"length", 0) or 0
            path_parts = f.get(b"path") or []
            fname = b"/".join(p for p in path_parts if isinstance(p, bytes)).decode("utf-8", "replace")
            flat.append((fname, length))
    elif b"length" in meta:
        flat.append((info["name"] or "", meta.get(b"length", 0) or 0))

    info["files"] = len(flat)
    for fname, length in flat:
        info["total_size"] += length
        lower = fname.lower()
        if lower.endswith(".rar") or any(lower.endswith(f".r{n:02d}") for n in range(100)):
            info["is_rar"] = True
            info["rar_parts"] += 1
        else:
            for ext in VIDEO_EXTS:
                if lower.endswith(ext) and length > info["video_size"]:
                    info["video_size"] = length
                    info["video_name"] = fname
                    break
    return info


def human_size(n):
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024:
            return f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} PB"
