import re
from urllib.parse import urljoin, urlparse, quote as urlquote
import requests
from bs4 import BeautifulSoup
import xbmcaddon
import xbmc
from . import domain
from . import anubis

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
TIMEOUT = 15

HEADERS = {
    "User-Agent": UA,
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "es-ES,es;q=0.9",
}

_ADDON = xbmcaddon.Addon()


def _proxy_base():
    raw = (_ADDON.getSetting("proxy_url") or "").strip().rstrip("/")
    return raw or None


def _proxy_force():
    return (_ADDON.getSetting("proxy_force") or "").lower() == "true"


def _anubis_cookies_for(url):
    """Return cached Anubis cookies dict for *url*'s domain, or {}.

    Falls back to any cached dontorrent domain in case the canonical
    redirect domain differs from the alias in the URL.
    """
    try:
        host = urlparse(url).hostname
        if not host:
            return {}
        cached = anubis.get_cached_cookies(host)
        if cached:
            return cached
        if "dontorrent" in host:
            for domain_key in list(anubis._cookie_cache.keys()):
                if "dontorrent" in domain_key:
                    c = anubis.get_cached_cookies(domain_key)
                    if c:
                        return c
        return {}
    except Exception:
        return {}


def _extract_response_cookies(response):
    """Extract cookies from response headers (via proxy's Set-Cookie).

    Uses response.raw.headers.getlist() to get each Set-Cookie header
    individually — response.headers.items() merges them into one string.
    """
    cookies = {}
    try:
        raw_cookies = response.raw.headers.getlist("Set-Cookie")
        for sc in raw_cookies:
            parts = sc.split(";")
            if "=" in parts[0]:
                cn, cv = parts[0].split("=", 1)
                cn, cv = cn.strip(), cv.strip()
                if cn and cv:
                    cookies[cn] = cv
    except Exception:
        for key, value in response.headers.items():
            if key.lower() == "set-cookie":
                parts = value.split(";")
                if "=" in parts[0]:
                    cn, cv = parts[0].split("=", 1)
                    cn, cv = cn.strip(), cv.strip()
                    if cn and cv:
                        cookies[cn] = cv
    # Also check response.cookies (requests built-in)
    for name, value in response.cookies.items():
        cookies[name] = value
    return cookies


def _handle_anubis(response, original_url):
    """If *response* is an Anubis challenge, solve it and retry.

    Returns the real response on success, or the original on failure.
    """
    if not anubis.is_anubis(response.text):
        return response

    base = _proxy_base()
    if not base:
        xbmc.log("[scraper] Anubis detected but no proxy configured", xbmc.LOGWARNING)
        return response

    xbmc.log(f"[scraper] Anubis challenge detected for {original_url}", xbmc.LOGINFO)

    # CRITICAL: Extract cookies from the challenge response.
    # Anubis sets browser-pow-cookie-verification and needs it back
    # in the pass-challenge request, otherwise it returns "cookies disabled".
    init_cookies = _extract_response_cookies(response)

    # Use the relay-final URL (canonical domain after redirects)
    final_url = response.headers.get("x-mw-relay-final", original_url)

    cookies = anubis.solve_and_get_cookie(
        response.text, final_url, base, init_cookies=init_cookies
    )
    if not cookies:
        xbmc.log("[scraper] Anubis solve failed — no cookies", xbmc.LOGERROR)
        return response

    # Retry the original request with the Anubis cookies
    proxied = f"{base}/?u={urlquote(original_url, safe='')}"
    h = dict(HEADERS)
    h["Accept-Encoding"] = "identity"
    cookie_str = "; ".join(f"{k}={v}" for k, v in cookies.items())
    h["Cookie"] = cookie_str
    r = requests.get(proxied, timeout=30, headers=h)
    r.raise_for_status()

    if anubis.is_anubis(r.text):
        xbmc.log("[scraper] Still Anubis after solving — cookie rejected", xbmc.LOGERROR)
        return r

    xbmc.log(f"[scraper] Anubis bypassed OK for {original_url}", xbmc.LOGINFO)
    return r


def _ensure_anubis_cookies(url):
    """Pre-flight: make sure we have valid Anubis cookies for *url*'s domain.

    Each Kodi plugin invocation is a fresh Python process, so the in-memory
    cache is typically empty.  This function checks the persisted cache first,
    then does a lightweight GET to the domain root to trigger / solve Anubis
    if needed — before we attempt the real request.
    """
    cached = _anubis_cookies_for(url)
    if cached:
        return cached

    base = _proxy_base()
    if not base or not _proxy_force():
        return {}

    # GET the domain root — this is the cheapest request that will trigger
    # Anubis if we don't have valid cookies.
    from urllib.parse import urlparse
    parsed = urlparse(url)
    root_url = f"{parsed.scheme}://{parsed.hostname}/"
    proxied = f"{base}/?u={urlquote(root_url, safe='')}"
    h = dict(HEADERS)
    h["Accept-Encoding"] = "identity"

    try:
        xbmc.log(f"[scraper] Pre-flight GET to {root_url} to acquire Anubis cookies", xbmc.LOGINFO)
        r = requests.get(proxied, timeout=30, headers=h)
    except Exception as exc:
        xbmc.log(f"[scraper] Pre-flight GET failed: {exc}", xbmc.LOGWARNING)
        return {}

    if anubis.is_anubis(r.text):
        r = _handle_anubis(r, root_url)

    return _anubis_cookies_for(url)


def _proxy_get(url, **kwargs):
    """GET con soporte de proxy + Anubis auto-solver."""
    base = _proxy_base()
    if base and _proxy_force():
        proxied = f"{base}/?u={urlquote(url, safe='')}"
        kwargs.setdefault("timeout", 30)
        kwargs.setdefault("headers", HEADERS)
        h = dict(kwargs.get("headers", HEADERS))
        h["Accept-Encoding"] = "identity"
        # Add cached Anubis cookies if available
        cached = _anubis_cookies_for(url)
        if cached:
            h["Cookie"] = "; ".join(f"{k}={v}" for k, v in cached.items())
        kwargs["headers"] = h
        r = requests.get(proxied, **kwargs)

        # Check for Anubis BEFORE raise_for_status — the challenge page
        # may arrive as 200 or 403; we need to handle it either way.
        if anubis.is_anubis(r.text):
            r = _handle_anubis(r, url)

        # Fix r.url: when proxied, r.url is the *worker* URL
        # (e.g. https://mw-relay.…/…). Any caller that does
        # urljoin(r.url, relative_href) would build URLs pointing at the
        # worker instead of the upstream site → 403 on the next request.
        # The worker exposes the real upstream URL in x-mw-relay-final.
        final = r.headers.get("x-mw-relay-final")
        if final:
            try:
                r.url = final
            except Exception:
                pass

        r.raise_for_status()
        return r
    kwargs.setdefault("timeout", TIMEOUT)
    kwargs.setdefault("headers", HEADERS)
    r = requests.get(url, **kwargs)
    r.raise_for_status()
    return r


def _proxy_post(url, **kwargs):
    """POST con soporte de proxy + Anubis auto-solver."""
    base = _proxy_base()
    if base and _proxy_force():
        proxied = f"{base}/?u={urlquote(url, safe='')}"
        kwargs.setdefault("timeout", 30)
        kwargs.setdefault("headers", HEADERS)
        h = dict(kwargs.get("headers", HEADERS))
        h["Accept-Encoding"] = "identity"

        # Ensure Anubis cookies are available BEFORE the POST.
        # This avoids POST-originated Anubis challenges which are harder
        # to solve (pass-challenge returns 403 for POST-originated ones).
        cached = _anubis_cookies_for(url)
        if not cached:
            cached = _ensure_anubis_cookies(url)
        if cached:
            h["Cookie"] = "; ".join(f"{k}={v}" for k, v in cached.items())

        kwargs["headers"] = h
        r = requests.post(proxied, **kwargs)

        # If we STILL hit Anubis (cookies expired mid-request, etc.),
        # do a fresh GET solve and retry.
        if anubis.is_anubis(r.text):
            xbmc.log("[scraper] Anubis on POST — doing fresh GET solve", xbmc.LOGINFO)
            fresh = _ensure_anubis_cookies(url)
            if fresh:
                h["Cookie"] = "; ".join(f"{k}={v}" for k, v in fresh.items())
                kwargs["headers"] = h
                r = requests.post(proxied, **kwargs)

        # Fix r.url so callers see the upstream URL, not the proxy URL.
        final = r.headers.get("x-mw-relay-final")
        if final:
            try:
                r.url = final
            except Exception:
                pass

        r.raise_for_status()
        return r
    kwargs.setdefault("timeout", TIMEOUT)
    kwargs.setdefault("headers", HEADERS)
    r = requests.post(url, **kwargs)
    r.raise_for_status()
    return r

# --- URL paths confirmed against dontorrent.reisen (Nov 2026) ---------------
SECTION_PATH = {
    "movie":       "peliculas",
    "movie_hd":    "peliculas/hd",
    "movie_4k":    "peliculas/4K",
    "tvshow":      "series",
    "tvshow_hd":   "series/hd",
    "tvshow_4k":   "series/4k",
    "documentary": "documentales",
    "estrenos":    "",
}

ITEM_PATTERNS = {
    "movie":       re.compile(r"^/pelicula/\d+/"),
    "tvshow":      re.compile(r"^/serie/\d+/\d+/"),
    "documentary": re.compile(r"^/documental/\d+/\d+/"),
}


def _classify(href):
    for kind, pat in ITEM_PATTERNS.items():
        if pat.match(href):
            return kind
    return None


def _get(path):
    url = urljoin(domain.base_url() + "/", path.lstrip("/"))
    r = _proxy_get(url)
    return BeautifulSoup(r.text, "html.parser"), r.url


_TITLE_CACHE = {}


def fetch_detail_title(url):
    """Fetch the detail page's <h1> text, which (unlike the URL slug) keeps
    the original Spanish accents. Cached per URL to keep listing cheap."""
    if not url:
        return None
    if url in _TITLE_CACHE:
        return _TITLE_CACHE[url]
    try:
        r = _proxy_get(url)
        s = BeautifulSoup(r.text, "html.parser")
        h1 = s.select_one("h1.descargarTitulo, h1")
        txt = h1.get_text(" ", strip=True) if h1 else None
    except Exception:
        txt = None
    _TITLE_CACHE[url] = txt
    return txt


def _post(path, data):
    url = urljoin(domain.base_url() + "/", path.lstrip("/"))
    r = _proxy_post(url, data=data)
    return BeautifulSoup(r.text, "html.parser"), r.url


_SLUG_RE = re.compile(r"/(?:pelicula|serie|documental)/\d+/(?:\d+/)?(.+?)/?$")


def _title_from_slug(href):
    m = _SLUG_RE.search(href)
    if not m:
        return None
    slug = m.group(1).split("/")[-1]
    txt = slug.replace("-", " ").replace("_", " ").strip()
    return re.sub(r"\s+", " ", txt) or None


def _upgrade_weserv(src, width=500):
    """Rewrite an images.weserv.nl URL to request a larger poster.

    The site embeds thumbnails at w=120&h=165. Weserv can reproxy the same
    original image at any size, so we swap the resize params and URL-encode
    any brackets in the upstream URL (weserv rejects raw brackets).
    """
    if "images.weserv.nl" not in src:
        return src
    src = re.sub(r"([?&])w=\d+", r"\g<1>w=" + str(width), src)
    src = re.sub(r"([?&])h=\d+&?", r"\g<1>", src).rstrip("&?")
    src = src.replace("[", "%5B").replace("]", "%5D")
    return src


def _img_src(a):
    img = a.find("img")
    if not img:
        return None
    src = img.get("src") or img.get("data-src") or img.get("data-original")
    if not src:
        return None
    if src.startswith("//"):
        src = "https:" + src
    return _upgrade_weserv(src, width=500)


_QUALITY_RE = re.compile(
    r"\(([^)]*(?:1080p|720p|2160p|4K|HDRip|BluRay|BDRip|BDremux|BRRip|WEB-?DL|WEBRip|microHD|HDTV|x264|x265|HEVC|DVDRip)[^)]*)\)",
    re.IGNORECASE,
)


def _quality_near(a):
    """On search pages the quality is a sibling <span>(BDremux-1080p)</span>
    right after the anchor. List pages don't have it; return None there."""
    for sib in a.next_siblings:
        # Tag nodes: check badge class to stop before "Película/Serie".
        get_attr = getattr(sib, "get", None)
        if callable(get_attr):
            classes = get_attr("class") or []
            if "badge" in classes:
                break
            txt = sib.get_text(" ", strip=True)
        else:
            # NavigableString
            txt = str(sib).strip()
        if not txt:
            continue
        m = _QUALITY_RE.search(txt)
        if m:
            return m.group(1).strip()
    parent = a.parent
    if parent is not None:
        m = _QUALITY_RE.search(parent.get_text(" ", strip=True))
        if m:
            return m.group(1).strip()
    return None


def _items(soup, page_url, kind_filter=None):
    items, seen = [], set()
    for a in soup.select("a[href]"):
        href = a.get("href", "")
        kind = _classify(href)
        if not kind:
            continue
        if kind_filter and kind != kind_filter:
            continue
        if href in seen:
            continue
        seen.add(href)
        title = (a.get("title") or "").strip()
        if not title:
            title = (a.get_text() or "").strip()
        if not title:
            title = _title_from_slug(href) or ""
        if not title:
            continue
        title = re.sub(r"\s+", " ", title).rstrip(" .")
        items.append({
            "title": title,
            "url": urljoin(page_url, href),
            "kind": kind,
            "image": _img_src(a),
            "quality": _quality_near(a),
        })
    return items


def latest(kind="movie", page=1):
    # "Estrenos" pulls from the homepage, optionally filtered by kind
    if kind in ("estrenos", "estrenos_movie", "estrenos_tvshow"):
        path = "" if page <= 1 else f"page/{page}"
        soup, url = _get(path)
        kf = None
        if kind == "estrenos_movie":
            kf = "movie"
        elif kind == "estrenos_tvshow":
            kf = "tvshow"
        return _items(soup, url, kind_filter=kf)
    section = SECTION_PATH.get(kind, "peliculas")
    path = section if page <= 1 else f"{section}/page/{page}"
    soup, url = _get(path)
    return _items(soup, url, kind_filter=_base_kind(kind))


def _base_kind(kind):
    """Quality variants (movie_hd, movie_4k, tvshow_hd, tvshow_4k) collapse
    back to their root kind for item classification."""
    if kind.startswith("movie"):
        return "movie"
    if kind.startswith("tvshow"):
        return "tvshow"
    return kind


def search(query):
    soup, url = _post("buscar", data={"valor": query, "Buscar": "Buscar"})
    return _items(soup, url)


def detail(url):
    r = _proxy_get(url)
    soup = BeautifulSoup(r.text, "html.parser")

    # Title
    title = None
    h1 = soup.select_one("h1.descargarTitulo, h1, h2.descargarTitulo")
    if h1:
        title = h1.get_text(" ", strip=True)

    # Description
    plot = None
    for p in soup.select("p.text-justify, p"):
        txt = p.get_text(" ", strip=True)
        if txt.lower().startswith("descripci") or txt.lower().startswith("sinopsis"):
            plot = re.sub(r"^[^:]+:\s*", "", txt)
            break
        if not plot and len(txt) > 140:
            plot = txt

    # Poster from og:image (images.weserv.nl proxy - upgrade to HD)
    image = None
    og = soup.find("meta", property="og:image")
    if og and og.get("content"):
        image = _upgrade_weserv(og["content"], width=500)

    # Year/genre from labelled <p> blocks
    year = None
    m = re.search(r"\b(19|20)\d{2}\b", soup.get_text(" ", strip=True))
    if m:
        year = m.group(0)

    # Downloads: each <a class="protected-download" data-content-id data-tabla>.
    # For series, each row is wrapped in <tr> with the episode label in a <td>.
    downloads = []
    for a in soup.select("a.protected-download"):
        cid = a.get("data-content-id")
        tabla = a.get("data-tabla")
        if not cid or not tabla:
            continue
        label = "Descargar"
        season = episode = None
        tr = a.find_parent("tr")
        if tr:
            tds = [t.get_text(" ", strip=True) for t in tr.find_all("td")]
            for t in tds:
                m = re.match(r"^(\d{1,2})\s*x\s*(\d{1,3})\b", t)
                if m:
                    season, episode = int(m.group(1)), int(m.group(2))
                    label = f"{season:02d}x{episode:02d}"
                    extra = t[m.end():].strip(" -()[]")
                    if extra:
                        label += f" {extra}"
                    break
            extras = [t for t in tds if t and t != label and not t.lower().startswith("descargar")]
            if extras:
                label = f"{label} - " + " · ".join(extras[:2]) if season is not None else " · ".join(extras[:2])
        downloads.append({
            "content_id": cid,
            "tabla": tabla,
            "label": label,
            "season": season,
            "episode": episode,
        })

    return {
        "title": title,
        "plot": plot,
        "image": image,
        "year": year,
        "downloads": downloads,
    }
