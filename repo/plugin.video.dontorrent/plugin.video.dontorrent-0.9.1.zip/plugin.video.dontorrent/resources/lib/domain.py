import re
import time
import requests
from bs4 import BeautifulSoup
import xbmcaddon

ADDON = xbmcaddon.Addon()

DOMAIN_RE = re.compile(
    r'(?:https?://)?(?:www\.)?(don[a-z0-9\-]*torrent[a-z0-9\-]*\.[a-z]{2,8})',
    re.IGNORECASE,
)

# Actualizados mayo 2026 — dominios activos (Anubis PoW, todos equivalentes)
FALLBACK_DOMAINS = [
    "dontorrent.irish",
    "dontorrent.lighting",
    "dontorrent.istanbul",
    "dontorrent.onl",
    "dontorrent.kids",
    "dontorrent.kiwi",
    "dontorrent.live",
    "dontorrent.phd",
    "dontorrent.club",
    "dontorrent.info",
    "dontorrent.pink",
    "dontorrent.reisen",
]

UA = ("Mozilla/5.0 (Linux; Android 13; SM-S911B) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36")


def _session():
    s = requests.Session()
    s.headers.update({
        "User-Agent": UA,
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "es-ES,es;q=0.9",
    })
    return s


def parse_telegram(channel):
    """Return (available_hosts, censored_hosts) from a channel preview.

    Each post is analysed individually: domains in posts with the ✅ emoji or
    the word 'Disponible' are considered available; those with ❌ or
    'Censurado' are considered dead.
    """
    url = f"https://t.me/s/{channel}"
    try:
        r = _session().get(url, timeout=12)
        r.raise_for_status()
    except Exception:
        return [], set()

    soup = BeautifulSoup(r.text, "html.parser")
    posts = soup.select(".tgme_widget_message_text") or soup.select(".tgme_widget_message")
    available, censored = [], set()

    for msg in posts:
        text = msg.get_text(" ", strip=True)
        low = text.lower()
        hosts = []
        for m in DOMAIN_RE.finditer(text):
            hosts.append(m.group(1).lower())
        # Also look inside anchor hrefs
        for a in msg.select("a[href]"):
            for m in DOMAIN_RE.finditer(a.get("href", "")):
                hosts.append(m.group(1).lower())
        hosts = list(dict.fromkeys(hosts))
        if not hosts:
            continue

        is_available = ("\u2705" in text) or ("disponible" in low)
        is_censored = ("\u274c" in text) or ("censurad" in low) or ("caido" in low) or ("caído" in low)

        for h in hosts:
            if is_available and not is_censored:
                available.append(h)
            elif is_censored:
                censored.add(h)

    # Telegram preview: oldest first, newest last -> reverse so newest wins
    available = list(reversed(available))
    seen, ordered = set(), []
    for h in available:
        if h in seen:
            continue
        seen.add(h)
        ordered.append(h)
    return ordered, censored


def _proxy_base():
    raw = (ADDON.getSetting("proxy_url") or "").strip().rstrip("/")
    return raw or None


def _proxy_force():
    return (ADDON.getSetting("proxy_force") or "").lower() == "true"


def _probe(host):
    from urllib.parse import quote as urlquote
    url = f"https://{host}/"
    proxy = _proxy_base()
    try:
        if proxy and _proxy_force():
            # Try with cached Anubis cookies first
            from . import anubis
            cached_cookies = anubis.get_cached_cookies(host)
            headers = dict(_session().headers)
            headers["Accept-Encoding"] = "identity"
            if cached_cookies:
                headers["Cookie"] = "; ".join(
                    f"{k}={v}" for k, v in cached_cookies.items()
                )
            proxied = f"{proxy}/?u={urlquote(url, safe='')}"
            r = _session().get(proxied, timeout=20, allow_redirects=True,
                               headers=headers)
        else:
            r = _session().get(url, timeout=10, allow_redirects=True)
    except Exception:
        return None
    if r.status_code != 200:
        return None

    body_text = r.text

    # Handle Anubis anti-bot challenge
    if proxy and _proxy_force():
        try:
            from . import anubis
            if anubis.is_anubis(body_text):
                # CRITICAL: extract cookies from the challenge response.
                # Anubis requires browser-pow-cookie-verification to validate.
                init_cookies = {}
                for hdr_key, hdr_val in r.headers.items():
                    if hdr_key.lower() == "set-cookie":
                        parts = hdr_val.split(";")
                        if "=" in parts[0]:
                            cn, cv = parts[0].split("=", 1)
                            cn, cv = cn.strip(), cv.strip()
                            if cn and cv:
                                init_cookies[cn] = cv
                for cn2, cv2 in r.cookies.items():
                    init_cookies[cn2] = cv2
                # Use the relay-final URL (canonical domain after redirects)
                final = r.headers.get("x-mw-relay-final", url)
                cookies = anubis.solve_and_get_cookie(
                    body_text, final, proxy, init_cookies=init_cookies
                )
                if cookies:
                    headers2 = dict(_session().headers)
                    headers2["Accept-Encoding"] = "identity"
                    headers2["Cookie"] = "; ".join(
                        f"{k}={v}" for k, v in cookies.items()
                    )
                    r = _session().get(proxied, timeout=20,
                                       allow_redirects=True, headers=headers2)
                    if r.status_code == 200:
                        body_text = r.text
        except Exception:
            pass

    body = body_text.lower()
    if not any(k in body for k in ("torrent", "pelicula", "serie")):
        return None
    # Si viene via proxy, el header x-mw-relay-final tiene la URL real
    final_url = r.headers.get("x-mw-relay-final", r.url)
    m = re.match(r'https?://([^/]+)', final_url)
    return (m.group(1).lower() if m else host)


def resolve(force=False):
    manual = ADDON.getSetting("manual_domain").strip()
    if manual:
        return manual.replace("https://", "").replace("http://", "").rstrip("/")

    cached = ADDON.getSetting("cached_domain").strip()
    try:
        cached_at = int(ADDON.getSetting("cached_at") or "0")
    except ValueError:
        cached_at = 0
    try:
        ttl_hours = int(ADDON.getSetting("cache_hours") or "12")
    except ValueError:
        ttl_hours = 12
    ttl = max(1, ttl_hours) * 3600

    if not force and cached and (time.time() - cached_at) < ttl:
        return cached

    # --- Supabase: dominio centralizado (prioridad maxima) ---
    supabase_domain = None
    supabase_fallbacks = []
    try:
        from . import supabase_sync as sb
        supabase_domain = sb.get_domain("dontorrent")
        supabase_fallbacks = sb.get_fallback_domains("dontorrent")
    except Exception:
        pass

    channel = ADDON.getSetting("telegram_channel").strip() or "DonTorrent"
    tg_available, tg_censored = parse_telegram(channel)

    # Orden de prioridad: Supabase > Telegram > cached > fallbacks hardcoded
    ordered, seen = [], set()
    sources = (
        ([supabase_domain] if supabase_domain else [])
        + supabase_fallbacks
        + tg_available
        + ([cached] if cached else [])
        + FALLBACK_DOMAINS
    )
    for h in sources:
        if h and h not in seen and h not in tg_censored:
            seen.add(h)
            ordered.append(h)

    for host in ordered:
        resolved = _probe(host)
        if resolved:
            ADDON.setSetting("cached_domain", resolved)
            ADDON.setSetting("cached_at", str(int(time.time())))
            return resolved

    return cached or FALLBACK_DOMAINS[0]


def base_url(force=False):
    return f"https://{resolve(force)}"


def diagnose():
    channel = ADDON.getSetting("telegram_channel").strip() or "DonTorrent"
    avail, cens = parse_telegram(channel)
    resolved = resolve(force=True)
    return {
        "channel": channel,
        "telegram_available": avail,
        "telegram_censored": sorted(cens),
        "resolved": resolved,
    }
