"""WolfMax4k provider.

Fixed domain (`wolfmax4k.com`), low/no anti-scraping, premium 1080p/4K.
Telegram channel kept as a backup if the domain ever rotates.
"""
import re
from urllib.parse import urljoin
import requests
from bs4 import BeautifulSoup

from .. import util, torrent, quality
from ..resolver import DomainResolver
from .base import BaseProvider, Result


class WolfMax4k(BaseProvider):
    name = "wolfmax4k"
    display = "WolfMax4k"

    def __init__(self):
        self.resolver = DomainResolver(
            name="wolfmax4k",
            brand_pattern=r"wolfmax4k",
            fallbacks=["wolfmax4k.com", "wolfmax4k.net", "wolfmax4k.it.com"],
            telegram_channel="WolfMax4k",
        )

    # ------------------------------------------------------------------ http
    def _session(self):
        s = requests.Session()
        s.headers.update({
            "User-Agent": ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                           "AppleWebKit/537.36 (KHTML, like Gecko) "
                           "Chrome/120.0.0.0 Safari/537.36"),
            "Accept-Language": "es-ES,es;q=0.9",
        })
        return s

    # --------------------------------------------------------------- search
    def search(self, query, kind="movie"):
        base = self.resolver.base_url()
        if not base:
            return []
        try:
            # WolfMax4k uses ?s= search param (WordPress-style).
            r = self._session().get(
                f"{base}/?s=" + requests.utils.quote(query),
                timeout=util.setting("resolve_timeout", 15, int),
            )
            r.raise_for_status()
        except Exception as exc:
            util.debug(f"wolfmax4k: search failed: {exc}")
            return []

        soup = BeautifulSoup(r.text, "html.parser")
        # Each result is typically an <article> or <h2><a> link to the post.
        items = []
        seen = set()
        for a in soup.select("h2 a, h3 a, article a.post-link, a.titulo"):
            href = a.get("href") or ""
            if not href or href in seen:
                continue
            if not href.startswith("http"):
                href = urljoin(base, href)
            title = (a.get_text(" ", strip=True) or "").strip()
            if not title or len(title) < 3:
                continue
            seen.add(href)
            items.append((title, href))
            if len(items) >= util.setting("max_results_per_provider", 8, int):
                break

        results = []
        for title, page in items:
            magnet, info_hash, size, name, page_text = self._resolve_page(page)
            if not magnet:
                continue
            q = quality.merge(name or "", title, page_text or "")
            if not q["language"]:
                q["language"] = "CAST"
            results.append(Result(
                name=quality.format_label(self.display, name or title, q),
                uri=magnet,
                info_hash=info_hash,
                size=size,
                provider=self.display,
                resolution=q["resolution"],
                source=q["source"],
                codec=q["codec"],
                audio_lang=q["language"] or "CAST",
            ))
        return results

    # --------------------------------------------------------------- detail
    def _resolve_page(self, url):
        """Return (magnet, info_hash, size, name, page_text) for a post page."""
        try:
            r = self._session().get(url, timeout=util.setting("resolve_timeout", 15, int))
            r.raise_for_status()
        except Exception as exc:
            util.debug(f"wolfmax4k: detail {url} failed: {exc}")
            return None, None, 0, None, ""

        soup = BeautifulSoup(r.text, "html.parser")
        page_text = soup.get_text(" ", strip=True)[:1000]

        for a in soup.select("a[href^='magnet:']"):
            href = a.get("href") or ""
            return href, _hash_from_magnet(href), 0, None, page_text

        for a in soup.select("a[href$='.torrent'], a[href*='.torrent?']"):
            href = a.get("href") or ""
            if not href.startswith("http"):
                href = urljoin(url, href)
            info = torrent.inspect_torrent(href, headers={"Referer": url})
            if info.get("magnet"):
                return info["magnet"], info["info_hash"], info["size"], info.get("name"), page_text

        return None, None, 0, None, page_text


def _hash_from_magnet(magnet):
    m = re.search(r"btih:([a-fA-F0-9]{40}|[a-zA-Z2-7]{32})", magnet)
    return m.group(1).lower() if m else None
